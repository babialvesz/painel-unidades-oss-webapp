import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// --- DATABASE CACHE AND FETCHING ENGINE ---
const SPREADSHEET_ID = "SEU_SPREADSHEET_ID_AQUI";

interface CacheData {
  unidades: any[];
  ossList: any[];
  tic: any[];
  leitos: any[];
  pareceres: any[];
  producao: any[];
  analiseDesempenho: any[];
  metasSugeridas: any[];
  repasses: any[];
  especialidades: any[];
  lastUpdated: number;
}

let dataCache: CacheData | null = null;
let isFetching = false;

// Robust CSV Parser
function parseCSV(text: string): Record<string, string>[] {
  const lines: string[][] = [];
  let row: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];
    
    if (inQuotes) {
      if (char === '"') {
        if (next === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        row.push(current);
        current = '';
      } else if (char === '\r' || char === '\n') {
        row.push(current);
        current = '';
        if (row.length > 0 && row.some(cell => cell.trim() !== '')) {
          lines.push(row);
        }
        row = [];
        if (char === '\r' && next === '\n') {
          i++;
        }
      } else {
        current += char;
      }
    }
  }
  if (row.length > 0 || current !== '') {
    row.push(current);
    if (row.some(cell => cell.trim() !== '')) {
      lines.push(row);
    }
  }
  
  if (lines.length < 2) return [];
  const headers = lines[0].map(h => h.replace(/^"(.*)"$/, '$1').trim());
  const data: Record<string, string>[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const rowData = lines[i];
    const item: Record<string, string> = {};
    for (let j = 0; j < headers.length; j++) {
      let val = rowData[j] || '';
      val = val.trim();
      if (val.startsWith('"') && val.endsWith('"')) {
        val = val.substring(1, val.length - 1).trim();
      }
      item[headers[j]] = val;
    }
    data.push(item);
  }
  
  return data;
}

function getField(p: Record<string, any>, ...keys: string[]): string {
  if (!p) return '';
  for (const k of keys) {
    if (p[k] !== undefined && p[k] !== null && String(p[k]).trim() !== '') {
      return String(p[k]).trim();
    }
  }
  const pKeys = Object.keys(p);
  for (const keyToFind of keys) {
    const normToFind = keyToFind.toLowerCase().replace(/[^a-z0-9]/g, '');
    const foundKey = pKeys.find(k => k.toLowerCase().replace(/[^a-z0-9]/g, '') === normToFind);
    if (foundKey && p[foundKey] !== undefined && p[foundKey] !== null && String(p[foundKey]).trim() !== '') {
      return String(p[foundKey]).trim();
    }
  }
  return '';
}

function parseYear(anoStr: string): number {
  if (!anoStr) return 0;
  const match4 = anoStr.match(/\b(20\d{2})\b/);
  if (match4) return parseInt(match4[1], 10);
  const match2 = anoStr.match(/\/(\d{2})$/);
  if (match2) return 2000 + parseInt(match2[1], 10);
  const num = parseInt(anoStr, 10);
  if (!isNaN(num) && num > 2000) return num;
  return 0;
}

// Normalization & Fuzzy Match
function normalizeName(name: string): string {
  if (!name) return '';
  // Remove parenthesis and content inside them
  let normalized = name.replace(/\([^)]*\)/g, '');
  // Convert to lowercase
  normalized = normalized.toLowerCase();
  // Normalize accents
  normalized = normalized.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  // Remove punctuation and extra whitespace
  normalized = normalized.replace(/[.,\/#!$%\^&\*;:{}=\-_`~?]/g, " ");
  normalized = normalized.replace(/\s+/g, ' ').trim();
  return normalized;
}

function isApproximateMatch(nameA: string, nameB: string): boolean {
  const normA = normalizeName(nameA);
  const normB = normalizeName(nameB);
  if (!normA || !normB) return false;
  if (normA === normB) return true;
  if (normA.includes(normB) || normB.includes(normA)) return true;
  
  const wordsA = normA.split(' ').filter(w => w.length > 2);
  const wordsB = normB.split(' ').filter(w => w.length > 2);
  if (wordsA.length === 0 || wordsB.length === 0) return false;
  
  const intersection = wordsA.filter(w => wordsB.includes(w));
  const minLength = Math.min(wordsA.length, wordsB.length);
  const overlapRatio = intersection.length / minLength;
  
  return overlapRatio >= 0.7;
}

function normalizeText(text: string): string {
  if (!text) return '';
  return text.toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const SIGLA_KEYWORDS: Record<string, string[]> = {
  APAMI: ["apami", "surubim", "iga", "ibdah"],
  FGH: ["fgh", "martiniano", "gestao hospitalar martiniano"],
  FMSA: ["fmsa", "manoel da silva", "maria lucinda", "manual da silva"],
  HCP: ["hcp", "sociedade pernambucana de combate", "cancer", "spcc", "pernambucana de combate ao cancer"],
  HTRI: ["htri", "tricentenario", "tricentenário"],
  IMIP: ["imip", "fernando figueira", "materno infantil", "medicina integral"],
  ISMEP: ["ismep", "medianeiras", "santa maria", "medianeiras da paz"],
  S3: ["s3", "ubaira"],
  CISNE: ["cisne", "icepes"]
};

function isOssMatchRefined(rowOss: string, targetSigla: string): boolean {
  if (!rowOss) return false;
  const rOssNorm = normalizeText(rowOss);
  const tSigla = targetSigla.trim().toUpperCase();

  // 1. Prevent "Fundação Professor Martiniano Fernandes- IMIP" from matching IMIP
  if (rOssNorm.includes("martiniano")) {
    if (tSigla === "FGH") return true;
    if (tSigla === "IMIP") return false;
  }

  // 2. Resolve S3 vs APAMI
  const hasUbairaOrS3 = rOssNorm.includes("ubaira") || rOssNorm.includes("s3");
  const hasApamiOrSurubim = rOssNorm.includes("apami") || rOssNorm.includes("surubim");
  const hasProtecaoMaternidade = rOssNorm.includes("protecao a maternidade") || rOssNorm.includes("protecao a maternidade e a infancia") || rOssNorm.includes("protecao a maternidade e infancia");

  if (hasUbairaOrS3) {
    if (tSigla === "S3") return true;
    if (tSigla === "APAMI") return false;
  } else if (hasApamiOrSurubim || hasProtecaoMaternidade) {
    if (tSigla === "APAMI") return true;
    if (tSigla === "S3") return false;
  }

  const keywords = SIGLA_KEYWORDS[tSigla] || [];
  for (const keyword of keywords) {
    const keywordNorm = normalizeText(keyword);
    if (rOssNorm.includes(keywordNorm)) {
      return true;
    }
  }
  
  return false;
}

// Calculate status
function calculateStatus(unitName: string, ossSigla: string, analiseDesempenho: any[]): 'verde' | 'ambar' | 'cinza' {
  const row = analiseDesempenho.find(r => {
    const rOss = r.OSS || r.oss || '';
    const rUnit = r.Unidade || r.unidade || '';
    return rOss.toUpperCase() === ossSigla.toUpperCase() && isApproximateMatch(rUnit, unitName);
  });

  if (!row) return 'cinza';
  
  const pontosFortes = (row.Pontos_Fortes || row.pontos_fortes || '').trim();
  const debilidades = (row.Debilidades || row.debilidades || '').trim();

  if (debilidades) {
    return 'ambar';
  } else if (pontosFortes) {
    return 'verde';
  } else {
    return 'cinza';
  }
}

// Map Portuguese Months to Sorter Key
const monthsMap: Record<string, number> = { 
  'janeiro': 1, 'fevereiro': 2, 'marco': 3, 'março': 3, 'abril': 4, 'maio': 5, 
  'junho': 6, 'julho': 7, 'agosto': 8, 'setembro': 9, 'outubro': 10, 'novembro': 11, 'dezembro': 12 
};

// Fetch data from sheet
async function fetchAllData(): Promise<CacheData> {
  const sheets = {
    unidades: "Unidades",
    ossLegenda: "OSS (legenda)",
    tic: "TIC",
    leitos: "Leitos (resumo)",
    pareceres: "Pareceres CTAI",
    producao: "Produção",
    analiseDesempenho: "Análise de Desempenho",
    metasSugeridas: "Metas de Produção Sugeridas",
    repasses: "Repasses",
    especialidades: "Especialidades"
  };

  const results: any = {};
  for (const [key, sheetName] of Object.entries(sheets)) {
    const encoded = encodeURIComponent(sheetName);
    const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encoded}`;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Status ${res.status}`);
      const text = await res.text();
      results[key] = parseCSV(text);
    } catch (err: any) {
      console.error(`Error loading sheet "${sheetName}":`, err.message);
      results[key] = [];
    }
  }

  // Preprocess OSS
  const rawUnidades = results.unidades;
  const rawOssLegenda = results.ossLegenda;
  
  const ossCounts: Record<string, number> = {};
  rawUnidades.forEach((u: any) => {
    const oss = u.OSS || u.oss;
    if (oss) {
      ossCounts[oss] = (ossCounts[oss] || 0) + 1;
    }
  });

  const ossList = rawOssLegenda.map((l: any) => {
    const sigla = l.Sigla || l.sigla || '';
    return {
      sigla,
      razao_social: l["Razão social"] || l.razao_social || '',
      cnpj: l.CNPJ || l.cnpj || '',
      count: ossCounts[sigla] || 0
    };
  });

  // Keep any remaining OSS not explicitly in legend
  Object.keys(ossCounts).forEach(sigla => {
    if (!ossList.some((o: any) => o.sigla.toUpperCase() === sigla.toUpperCase())) {
      ossList.push({
        sigla,
        razao_social: sigla,
        cnpj: '',
        count: ossCounts[sigla]
      });
    }
  });

  return {
    unidades: rawUnidades,
    ossList: ossList.filter((o: any) => o.sigla),
    tic: results.tic,
    leitos: results.leitos,
    pareceres: results.pareceres,
    producao: results.producao,
    analiseDesempenho: results.analiseDesempenho,
    metasSugeridas: results.metasSugeridas,
    repasses: results.repasses,
    especialidades: results.especialidades || [],
    lastUpdated: Date.now()
  };
}

// Retrieve from cache or fetch
async function getCachedData(): Promise<CacheData> {
  const CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  if (!dataCache) {
    console.log("[CACHE] No cache found. Fetching initial dataset...");
    dataCache = await fetchAllData();
    return dataCache;
  }

  const isExpired = Date.now() - dataCache.lastUpdated > CACHE_TTL;
  if (isExpired && !isFetching) {
    isFetching = true;
    console.log("[CACHE] Expired. Initiating background refresh...");
    fetchAllData()
      .then((fresh) => {
        dataCache = fresh;
        console.log("[CACHE] Background refresh successful.");
      })
      .catch((err) => {
        console.error("[CACHE] Background refresh failed:", err);
      })
      .finally(() => {
        isFetching = false;
      });
  }

  return dataCache;
}

// --- SECURE GOOGLE FIREBASE AUTHENTICATION ---
async function verifyFirebaseToken(token: string): Promise<{ email: string } | null> {
  if (!token) return null;
  const apiKey = "SUA_FIREBASE_API_KEY_AQUI"; // Firebase client key is perfect for public token verification
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${apiKey}`;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken: token })
    });
    if (!res.ok) {
      return null;
    }
    const data = await res.json() as any;
    if (data && data.users && data.users[0]) {
      return { email: data.users[0].email };
    }
    return null;
  } catch (error) {
    console.error("Firebase token verification failure:", error);
    return null;
  }
}

// Auth Middleware
async function authMiddleware(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Sessão não autenticada. Faça login." });
  }
  const token = authHeader.split(" ")[1];
  const user = await verifyFirebaseToken(token);
  if (!user) {
    return res.status(401).json({ error: "Sessão inválida ou expirada. Faça login novamente." });
  }

  const email = user.email.toLowerCase();
  
  // Verify organization or allowed email constraints
  const allowedIndividualEmails = [
    "exemplo.institucional@gmail.com",
    "seu.email@gmail.com",
    "exemplo.gestor1@gmail.com",
    "exemplo.gestor2@gmail.com",
    "exemplo.gestor3@gmail.com"
  ];

  let isAuthorized = false;
  if (allowedIndividualEmails.includes(email)) {
    isAuthorized = true;
  } else if (email.endsWith("@ses.pe.gov.br")) {
    isAuthorized = true;
  } else if (process.env.AUTHORIZED_EMAILS) {
    const authEmails = process.env.AUTHORIZED_EMAILS.split(",").map(e => e.trim().toLowerCase());
    if (authEmails.includes(email)) {
      isAuthorized = true;
    }
  }

  if (!isAuthorized) {
    return res.status(403).json({ error: `Acesso negado: o e-mail ${email} não possui autorização para este painel.` });
  }

  (req as any).user = user;
  next();
}

// --- API ENDPOINTS ---

// 0. Get Home Summary Metrics & Map Units
app.get("/api/home-summary", authMiddleware, async (req, res) => {
  try {
    const data = await getCachedData();
    
    const rawUnidades = data.unidades || [];
    const rawLeitos = data.leitos || [];

    const distinctOss = new Set<string>();
    let hospitaisCount = 0;
    let upasCount = 0;
    let upaesCount = 0;
    let carretasCount = 0;

    const mapUnits: any[] = [];

    rawUnidades.forEach(u => {
      const oss = (getField(u, 'OSS', 'oss') || '').trim();
      if (oss) distinctOss.add(oss.toUpperCase());

      const tipo = (getField(u, 'TIPO', 'tipo') || '').toUpperCase().trim();
      if (tipo.includes('HOSPITAL')) {
        hospitaisCount++;
      } else if (tipo === 'UPAE' || tipo.includes('UPAE')) {
        upaesCount++;
      } else if (tipo === 'UPA' || tipo.startsWith('UPA ')) {
        upasCount++;
      } else if (tipo.includes('CARRETA')) {
        carretasCount++;
      }

      const uName = getField(u, 'UNIDADE', 'unidade');
      const cidade = getField(u, 'CIDADE', 'cidade');
      const latStr = getField(u, 'LATITUDE', 'latitude', 'Lat', 'lat').replace(',', '.');
      const lngStr = getField(u, 'LONGITUDE', 'longitude', 'Long', 'long', 'lng').replace(',', '.');

      const lat = parseFloat(latStr);
      const lng = parseFloat(lngStr);

      const status = calculateStatus(uName, oss, data.analiseDesempenho);

      mapUnits.push({
        unidade: uName,
        oss,
        tipo: getField(u, 'TIPO', 'tipo') || 'Outros',
        cidade,
        latitude: !isNaN(lat) ? lat : null,
        longitude: !isNaN(lng) ? lng : null,
        status
      });
    });

    // Calculate total UTI beds
    let totalUti = 0;
    rawLeitos.forEach(l => {
      const utiValStr = getField(l, 'UTI', 'uti', 'Uti');
      if (utiValStr) {
        const cleaned = utiValStr.replace(/\./g, '').replace(/,/g, '.').replace(/[^0-9.]/g, '');
        const val = parseFloat(cleaned);
        if (!isNaN(val)) {
          totalUti += Math.round(val);
        }
      }
    });

    res.json({
      summary: {
        totalOss: distinctOss.size || data.ossList.length,
        hospitaisCount,
        upasCount,
        upaesCount,
        carretasCount,
        totalUti
      },
      mapUnits
    });
  } catch (err: any) {
    res.status(500).json({ error: "Erro ao carregar resumo e dados do mapa", details: err.message });
  }
});

// 1. Get OSS List with counts
app.get("/api/oss", authMiddleware, async (req, res) => {
  try {
    const data = await getCachedData();
    res.json(data.ossList);
  } catch (err: any) {
    res.status(500).json({ error: "Erro ao obter lista de OSS", details: err.message });
  }
});

// 2. Search Units
app.get("/api/units", authMiddleware, async (req, res) => {
  try {
    const searchQuery = (req.query.search as string || '').trim();
    if (searchQuery.length < 2) {
      return res.json([]);
    }

    const data = await getCachedData();
    const normalizedQuery = normalizeName(searchQuery);

    const filtered = data.unidades.filter(u => {
      const uName = u.UNIDADE || u.unidade || '';
      return normalizeName(uName).includes(normalizedQuery);
    });

    const results = filtered.map(u => {
      const uName = u.UNIDADE || u.unidade || '';
      const oss = u.OSS || u.oss || '';
      const tipo = u.TIPO || u.tipo || '';
      const cidade = u.CIDADE || u.cidade || '';
      const status = calculateStatus(uName, oss, data.analiseDesempenho);

      return {
        unidade: uName,
        oss,
        tipo,
        cidade,
        status
      };
    });

    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: "Erro ao buscar unidades", details: err.message });
  }
});

// 3. Get Units of a specific OSS
app.get("/api/oss/:sigla/units", authMiddleware, async (req, res) => {
  try {
    const sigla = req.params.sigla.toUpperCase();
    const data = await getCachedData();

    const filtered = data.unidades.filter(u => {
      const uOss = u.OSS || u.oss || '';
      return uOss.toUpperCase() === sigla;
    });

    const results = filtered.map(u => {
      const uName = u.UNIDADE || u.unidade || '';
      const oss = u.OSS || u.oss || '';
      const tipo = u.TIPO || u.tipo || '';
      const cidade = u.CIDADE || u.cidade || '';
      const status = calculateStatus(uName, oss, data.analiseDesempenho);

      return {
        unidade: uName,
        oss,
        tipo,
        cidade,
        status
      };
    });

    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: "Erro ao obter unidades da OSS", details: err.message });
  }
});

// 4. Get full Profile Detail of a specific health unit
app.get("/api/units/detail", authMiddleware, async (req, res) => {
  try {
    const { oss, unidade } = req.query as { oss: string; unidade: string };
    if (!oss || !unidade) {
      return res.status(400).json({ error: "Parâmetros oss e unidade são obrigatórios" });
    }

    const data = await getCachedData();

    // 1. Identificação (master record)
    const rawUnit = data.unidades.find(u => {
      const uOss = u.OSS || u.oss || '';
      const uName = u.UNIDADE || u.unidade || '';
      return uOss.toUpperCase() === oss.toUpperCase() && isApproximateMatch(uName, unidade);
    });

    if (!rawUnit) {
      return res.status(404).json({ error: "Unidade de saúde não localizada" });
    }

    const matchedUnitNameInMaster = rawUnit.UNIDADE || rawUnit.unidade;

    // 2. TIC Record
    const matchedTic = data.tic.find(t => {
      const tOss = t.OSS || t.oss || '';
      const tUnit = t.Unidade || t.unidade || '';
      return isOssMatchRefined(tOss, oss) && isApproximateMatch(tUnit, matchedUnitNameInMaster);
    });

    // 3. Leitos Record
    const matchedLeitos = data.leitos.find(l => {
      const lOss = l.OSS || l.oss || '';
      const lUnit = l.Unidade || l.unidade || '';
      return isOssMatchRefined(lOss, oss) && isApproximateMatch(lUnit, matchedUnitNameInMaster);
    });

    // 4. Pareceres CTAI (sorted by Year and Quarter desc)
    // Temporary debug logs as requested by the user
    console.log(`[PARECERES_DEBUG] Total de linhas brutas lidas da aba Pareceres CTAI antes do filtro: ${data.pareceres.length}`);
    console.log(`[PARECERES_DEBUG] Nome exato da unidade usado para comparar/casar: "${matchedUnitNameInMaster}"`);

    const matchedPareceres = data.pareceres.filter(p => {
      const pOss = p.OSS || p.oss || '';
      const pUnit = p.Unidade || p.unidade || '';
      return isOssMatchRefined(pOss, oss) && isApproximateMatch(pUnit, matchedUnitNameInMaster);
    });

    // Sorter for Pareceres: Year descending, Quarter descending
    const quarterOrder: Record<string, number> = { '1º Tri': 1, '2º Tri': 2, '3º Tri': 3, '4º Tri': 4, '1': 1, '2': 2, '3': 3, '4': 4 };
    matchedPareceres.sort((a, b) => {
      const yearA = parseInt(a.Ano || a.ano || '0', 10);
      const yearB = parseInt(b.Ano || b.ano || '0', 10);
      if (yearA !== yearB) return yearB - yearA;

      const qA = a.Trimestre || a.trimestre || '';
      const qB = b.Trimestre || b.trimestre || '';
      const orderA = quarterOrder[qA] || 0;
      const orderB = quarterOrder[qB] || 0;
      return orderB - orderA;
    });

    // 5. Produção (All indicators and historical monthly records)
    const matchedProducao = data.producao.filter(p => {
      const pOss = p.OSS || p.oss || '';
      const pUnit = p.Unidade || p.unidade || '';
      return isOssMatchRefined(pOss, oss) && isApproximateMatch(pUnit, matchedUnitNameInMaster);
    });

    // Temporary debug logs specifically for the requested unit
    if (matchedUnitNameInMaster.toLowerCase().includes("grande recife")) {
      const uniquePeriods = Array.from(new Set(matchedProducao.map(p => `${p.Ano || p.ano || ''}-${(p.Mês || p.mes || '').toLowerCase().trim()}`)));
      console.log(`[PRODUCAO_DEBUG] (a) Nome exato usado na consulta à aba "Produção": "${matchedUnitNameInMaster}"`);
      console.log(`[PRODUCAO_DEBUG] (b) Linhas de "Produção" encontradas: ${matchedProducao.length}`);
      console.log(`[PRODUCAO_DEBUG] (c) Lista de combinações Ano/Mês únicas para o seletor:`, uniquePeriods);
    }

    const producaoAll = matchedProducao.map(p => ({
      indicador: p.Indicador || p.indicador || '',
      ano: p.Ano || p.ano || '',
      mes: p.Mês || p.mes || '',
      meta: parseFloat((p.Meta || p.meta || '0').replace(/\./g, '').replace(/,/g, '.')) || 0,
      producao: parseFloat((p.Produção || p.producao || '0').replace(/\./g, '').replace(/,/g, '.')) || 0,
      percentual: p["%"] || p.percentual || '',
      statusMeta: p.Status_Meta || p.status_meta || ''
    }));

    // 6. Análise de Desempenho
    const matchedDesempenho = data.analiseDesempenho.find(d => {
      const dOss = d.OSS || d.oss || '';
      const dUnit = d.Unidade || d.unidade || '';
      return isOssMatchRefined(dOss, oss) && isApproximateMatch(dUnit, matchedUnitNameInMaster);
    });

    // 7. Metas de Produção Sugeridas
    const matchedMetasSugeridas = data.metasSugeridas.filter(m => {
      const mOss = m.OSS || m.oss || '';
      const mUnit = m.Unidade || m.unidade || '';
      return isOssMatchRefined(mOss, oss) && isApproximateMatch(mUnit, matchedUnitNameInMaster);
    });

    // 8. Repasses Financeiros
    const matchedRepasses = (data.repasses || []).filter(r => {
      const rOss = r.OSS || r.oss || '';
      const rUnit = r.Unidade || r.unidade || '';
      return isOssMatchRefined(rOss, oss) && isApproximateMatch(rUnit, matchedUnitNameInMaster);
    });

    matchedRepasses.sort((a, b) => {
      const getMonthNum = (comp: string) => {
        if (!comp) return 0;
        const clean = comp.toLowerCase().replace('competencia', '').replace('competência', '').trim();
        return monthsMap[clean] || 0;
      };

      const getYear = (item: any) => {
        const ob = item['O.B.'] || '';
        const matchOb = ob.match(/^(\d{4})OB/);
        if (matchOb) return parseInt(matchOb[1], 10);

        const sei = item.SEI || '';
        const matchSei = sei.match(/\/(\d{4})-\d+/);
        if (matchSei) return parseInt(matchSei[1], 10);

        return 2026;
      };

      const yearA = getYear(a);
      const yearB = getYear(b);
      if (yearA !== yearB) return yearB - yearA;

      const orderA = getMonthNum(a.Competência || a.competencia || '');
      const orderB = getMonthNum(b.Competência || b.competencia || '');
      return orderB - orderA;
    });

    const repassesLatest6 = matchedRepasses.slice(0, 6).map(r => ({
      competencia: r.Competência || r.competencia || '',
      tipo: r.Tipo || r.tipo || '',
      projecao: r.Projeção || r.projecao || '',
      descontos: r.Descontos || r.descontos || '',
      projecaoAposDesconto: r["Projeção após Desconto"] || r.projecao_apos_desconto || '',
      saldoAPagarProvisaoFutura: r["Saldo à Pagar Provisão Futura"] || r.saldo_a_pagar_provisao_futura || '',
      saldoAPagarOss: r["Saldo à Pagar OSS"] || r.saldo_a_pagar_oss || '',
      pendencia: r.Pendência || r.pendencia || '',
      observacoes: r.Obervações || r.Observações || r.observacoes || r.obervacoes || ''
    }));

    // Format final consolidated profile
    const profile = {
      identificacao: {
        unidade: matchedUnitNameInMaster,
        oss: rawUnit.OSS || rawUnit.oss || '',
        contrato: rawUnit.CONTRATO || rawUnit.contrato || '',
        tipo: rawUnit.TIPO || rawUnit.tipo || '',
        macro: rawUnit.MACRO || rawUnit.macro || '',
        geres: rawUnit.GERES || rawUnit.geres || '',
        cidade: rawUnit.CIDADE || rawUnit.cidade || '',
        situacao: rawUnit.SITUAÇÃO || rawUnit.situacao || '',
        cnpjUnidade: rawUnit["CNPJ UNIDADE"] || rawUnit.cnpj_unidade || '',
        cnpjOss: rawUnit["CNPJ OSS"] || rawUnit.cnpj_oss || '',
        cnes: rawUnit.CNES || rawUnit.cnes || '',
        enderecoCompleto: rawUnit["ENDEREÇO COMPLETO"] || rawUnit.endereco_completo || ''
      },
      tic: matchedTic ? {
        sistemaUtilizado: matchedTic["Sistema utilizado"] || matchedTic.sistema_utilizado || '',
        tecnicoResponsavel: matchedTic["Técnico responsável"] || matchedTic.tecnico_responsavel || '',
        contatoResponsavel: matchedTic["Contato do responsável"] || matchedTic.contato_responsavel || '',
        modulos: matchedTic.Módulos || matchedTic.modulos || ''
      } : null,
      leitos: matchedLeitos ? {
        enfermaria: matchedLeitos.Enfermaria || matchedLeitos.enfermaria || '',
        cirurgia: matchedLeitos.Cirurgia || matchedLeitos.cirurgia || '',
        uti: matchedLeitos.UTI || matchedLeitos.uti || '',
        outros: matchedLeitos.Outros || matchedLeitos.outros || '',
        totalLeitos: matchedLeitos["Total leitos"] || matchedLeitos.total_leitos || ''
      } : null,
      pareceres: matchedPareceres.map(p => ({
        ano: getField(p, 'Ano', 'ano'),
        trimestre: getField(p, 'Trimestre', 'trimestre'),
        numeroParecer: getField(p, 'Número do Parecer', 'numero_parecer', 'Número Parecer', 'Numero Parecer'),
        resumoMetas: getField(p, 'Resumo do cumprimento de metas', 'resumo_metas', 'Resumo Metas', 'Resumo'),
        pendenciasDescontos: getField(p, 'Pendências/descontos apontados', 'pendencias_descontos', 'Pendencias Descontos'),
        dataParecer: getField(p, 'Data do parecer', 'data_parecer', 'Data Parecer'),
        observacoes: getField(p, 'Observações', 'observacoes'),
        temDescontoFinanceiro: getField(p, 'Tem_Desconto_Financeiro', 'Tem Desconto Financeiro', 'tem_desconto_financeiro', 'Tem Desconto'),
        categoriaApontamento: getField(p, 'Categoria_Apontamento', 'Categoria Apontamento', 'categoria_apontamento', 'Categoria'),
        percentualValor: getField(p, 'Percentual_Valor', 'Percentual Valor', 'Percentual/Valor', 'percentual_valor', 'Percentual', 'Valor')
      })),
      apontamentosDesconto: matchedPareceres
        .map(p => {
          const temDesconto = getField(p, 'Tem_Desconto_Financeiro', 'Tem Desconto Financeiro', 'tem_desconto_financeiro', 'Tem Desconto');
          return {
            ano: getField(p, 'Ano', 'ano'),
            trimestre: getField(p, 'Trimestre', 'trimestre'),
            categoriaApontamento: getField(p, 'Categoria_Apontamento', 'Categoria Apontamento', 'categoria_apontamento', 'Categoria'),
            percentualValor: getField(p, 'Percentual_Valor', 'Percentual Valor', 'Percentual/Valor', 'percentual_valor', 'Percentual', 'Valor'),
            temDescontoFinanceiro: temDesconto
          };
        })
        .filter(p => {
          const val = (p.temDescontoFinanceiro || '').toLowerCase().trim();
          return val === 'sim' || val.startsWith('sim');
        })
        .slice(0, 6),
      especialidades: Array.from(new Set(producaoAll.map(p => p.indicador?.trim()).filter(Boolean))),
      producao: producaoAll,
      analiseDesempenho: matchedDesempenho ? {
        pontosFortes: matchedDesempenho.Pontos_Fortes || matchedDesempenho.pontos_fortes || '',
        debilidades: matchedDesempenho.Debilidades || matchedDesempenho.debilidades || '',
        sugestaoSuporteMonitoramento: matchedDesempenho.Sugestao_Suporte_Monitoramento || matchedDesempenho.sugestao_suporte_monitoramento || '',
        baseadoEm: matchedDesempenho.Baseado_em || matchedDesempenho.baseado_em || ''
      } : null,
      metasSugeridas: matchedMetasSugeridas.map(m => ({
        indicador: m.Indicador || m.indicador || '',
        metaAtual: m.Meta_Atual || m.meta_atual || '',
        producaoMediaRecente: m.Producao_Media_Recente || m.producao_media_recente || '',
        novaMetaSugerida: m.Nova_Meta_Sugerida || m.nova_meta_sugerida || '',
        justificativa: m.Justificativa || m.justificativa || ''
      })),
      repasses: repassesLatest6
    };

    // 9. Especialidades
    const matchedEspecialidades = (data.especialidades || []).filter(e => {
      const eOss = getField(e, 'OSS', 'oss');
      const eUnit = getField(e, 'Unidade', 'unidade');
      return isOssMatchRefined(eOss, oss) && isApproximateMatch(eUnit, matchedUnitNameInMaster);
    });

    const MONTHS_ORDER = [
      { name: 'Dezembro', keys: ['Dezembro', 'dezembro'] },
      { name: 'Novembro', keys: ['Novembro', 'novembro'] },
      { name: 'Outubro', keys: ['Outubro', 'outubro'] },
      { name: 'Setembro', keys: ['Setembro', 'setembro'] },
      { name: 'Agosto', keys: ['Agosto', 'agosto'] },
      { name: 'Julho', keys: ['Julho', 'julho'] },
      { name: 'Junho', keys: ['Junho', 'junho'] },
      { name: 'Maio', keys: ['Maio', 'maio'] },
      { name: 'Abril', keys: ['Abril', 'abril'] },
      { name: 'Março', keys: ['Março', 'Marco', 'março', 'marco'] },
      { name: 'Fevereiro', keys: ['Fevereiro', 'fevereiro'] },
      { name: 'Janeiro', keys: ['Janeiro', 'janeiro'] }
    ];

    // Group matched rows by numeric year descending to always prioritize the most recent year
    const yearMap = new Map<number, typeof matchedEspecialidades>();
    matchedEspecialidades.forEach(row => {
      const anoStr = getField(row, 'Ano', 'ano');
      const y = parseYear(anoStr);
      if (!yearMap.has(y)) {
        yearMap.set(y, []);
      }
      yearMap.get(y)!.push(row);
    });

    const sortedYears = Array.from(yearMap.keys()).sort((a, b) => b - a);

    let chosenMonthObj: typeof MONTHS_ORDER[number] | null = null;
    let chosenYearStr = '';
    let chosenRows: typeof matchedEspecialidades = [];

    for (const y of sortedYears) {
      const yRows = yearMap.get(y)!;
      for (const mObj of MONTHS_ORDER) {
        const hasEntry = yRows.some(row => {
          const val = getField(row, ...mObj.keys).trim();
          return val !== '' && val !== '-' && val.toLowerCase() !== 'null' && val.toLowerCase() !== 'undefined';
        });
        if (hasEntry) {
          chosenMonthObj = mObj;
          chosenYearStr = String(y > 0 ? y : '2026');
          chosenRows = yRows;
          break;
        }
      }
      if (chosenMonthObj) break;
    }

    let especialidadesInfo: { mes: string; ano: string; lista: { especialidade: string; tipo: string }[] } | null = null;

    if (chosenMonthObj) {
      const disponivelList: { especialidade: string; tipo: string }[] = [];
      const seenSpecs = new Set<string>();

      chosenRows.forEach(row => {
        const val = getField(row, ...chosenMonthObj!.keys).trim();
        const valLower = val.toLowerCase();
        if (valLower.startsWith('dispon') && !valLower.startsWith('não') && !valLower.startsWith('nao')) {
          const spec = getField(row, 'Especialidade', 'especialidade', 'Serviço', 'servico');
          const tipo = getField(row, 'Tipo da Especialidade', 'tipo_da_especialidade', 'Tipo Especialidade', 'Tipo', 'tipo');
          if (spec && !seenSpecs.has(spec.toLowerCase())) {
            seenSpecs.add(spec.toLowerCase());
            disponivelList.push({
              especialidade: spec,
              tipo: tipo || 'Geral'
            });
          }
        }
      });

      especialidadesInfo = {
        mes: chosenMonthObj.name,
        ano: chosenYearStr,
        lista: disponivelList
      };
    }

    (profile as any).especialidadesInfo = especialidadesInfo;

    res.json(profile);
  } catch (err: any) {
    res.status(500).json({ error: "Erro ao obter detalhes da unidade", details: err.message });
  }
});

// --- CLIENT SERVER ASSETS & DEV MIDDLEWARE ---
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SERVER] Painel de Unidades OSS running on http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Failed to start server:", err);
});

