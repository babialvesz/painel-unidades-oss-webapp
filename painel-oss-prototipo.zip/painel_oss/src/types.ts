export interface OSSInfo {
  sigla: string;
  razao_social: string;
  cnpj: string;
  count: number;
}

export interface MapUnit {
  unidade: string;
  oss: string;
  tipo: string;
  cidade: string;
  latitude: number | null;
  longitude: number | null;
  status: 'verde' | 'ambar' | 'cinza';
}

export interface HomeSummaryData {
  summary: {
    totalOss: number;
    hospitaisCount: number;
    upasCount: number;
    upaesCount: number;
    carretasCount: number;
    totalUti: number;
  };
  mapUnits: MapUnit[];
}

export interface UnitSummary {
  unidade: string;
  oss: string;
  tipo: string;
  cidade: string;
  status: 'verde' | 'ambar' | 'cinza';
}

export interface UnitIdentificacao {
  unidade: string;
  oss: string;
  contrato: string;
  tipo: string;
  macro: string;
  geres: string;
  cidade: string;
  situacao: string;
  cnpjUnidade: string;
  cnpjOss: string;
  cnes: string;
  enderecoCompleto: string;
}

export interface UnitTIC {
  sistemaUtilizado: string;
  tecnicoResponsavel: string;
  contatoResponsavel: string;
  modulos: string;
}

export interface UnitLeitos {
  enfermaria: string;
  cirurgia: string;
  uti: string;
  outros: string;
  totalLeitos: string;
}

export interface UnitParecer {
  ano: string;
  trimestre: string;
  numeroParecer: string;
  resumoMetas: string;
  pendenciasDescontos: string;
  dataParecer: string;
  observacoes: string;
  temDescontoFinanceiro?: string;
  categoriaApontamento?: string;
  percentualValor?: string;
}

export interface UnitApontamentoDesconto {
  ano: string;
  trimestre: string;
  categoriaApontamento: string;
  percentualValor: string;
  temDescontoFinanceiro?: string;
}

export interface UnitProducao {
  indicador: string;
  ano: string;
  mes: string;
  meta: number;
  producao: number;
  percentual: string;
  statusMeta: string;
}

export interface UnitDesempenho {
  pontosFortes: string;
  debilidades: string;
  sugestaoSuporteMonitoramento: string;
  baseadoEm: string;
}

export interface UnitMetaSugerida {
  indicador: string;
  metaAtual: string;
  producaoMediaRecente: string;
  novaMetaSugerida: string;
  justificativa: string;
}

export interface UnitRepasse {
  competencia: string;
  tipo: string;
  projecao: string;
  descontos: string;
  projecaoAposDesconto: string;
  saldoAPagarProvisaoFutura: string;
  saldoAPagarOss: string;
  pendencia: string;
  observacoes: string;
}

export interface EspecialidadeItem {
  especialidade: string;
  tipo: string;
}

export interface UnitEspecialidadesInfo {
  mes: string;
  ano: string;
  lista: EspecialidadeItem[];
}

export interface UnitProfileData {
  identificacao: UnitIdentificacao;
  tic: UnitTIC | null;
  leitos: UnitLeitos | null;
  pareceres: UnitParecer[];
  apontamentosDesconto?: UnitApontamentoDesconto[];
  producao: UnitProducao[];
  analiseDesempenho: UnitDesempenho | null;
  metasSugeridas: UnitMetaSugerida[];
  repasses: UnitRepasse[];
  especialidades?: string[];
  especialidadesInfo?: UnitEspecialidadesInfo | null;
}
