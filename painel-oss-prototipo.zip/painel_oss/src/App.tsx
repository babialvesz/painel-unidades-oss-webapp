import React, { useState, useEffect } from 'react';
import { auth, googleProvider } from './lib/firebase';
import { signInWithPopup, signOut, User } from 'firebase/auth';
import { OSSInfo, UnitSummary, UnitProfileData, HomeSummaryData } from './types';
import LoginScreen from './components/LoginScreen';
import Breadcrumb from './components/Breadcrumb';
import OssGrid from './components/OssGrid';
import UnitsList from './components/UnitsList';
import UnitProfile from './components/UnitProfile';
import SummaryBar from './components/SummaryBar';
import PernambucoMap from './components/PernambucoMap';
import ErrorBoundary from './components/ErrorBoundary';
import { Shield, Search, LogOut, User as UserIcon, RefreshCw, Layers, LayoutGrid, MapPin } from 'lucide-react';

export default function App() {
  // Authentication & Session State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [verifiedToken, setVerifiedToken] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  // Business Data State
  const [ossList, setOssList] = useState<OSSInfo[]>([]);
  const [ossUnits, setOssUnits] = useState<UnitSummary[]>([]);
  const [searchResults, setSearchResults] = useState<UnitSummary[]>([]);
  const [selectedUnitProfile, setSelectedUnitProfile] = useState<UnitProfileData | null>(null);
  const [homeSummaryData, setHomeSummaryData] = useState<HomeSummaryData | null>(null);

  // Loading States
  const [isOssLoading, setIsOssLoading] = useState<boolean>(false);
  const [isUnitsLoading, setIsUnitsLoading] = useState<boolean>(false);
  const [isProfileLoading, setIsProfileLoading] = useState<boolean>(false);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [isSummaryLoading, setIsSummaryLoading] = useState<boolean>(false);

  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'oss' | 'unit'>('home');
  const [homeViewMode, setHomeViewMode] = useState<'oss' | 'map'>('map');
  const [selectedOssSigla, setSelectedOssSigla] = useState<string | null>(null);
  const [selectedUnitName, setSelectedUnitName] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Sincronização / Auto-Reload Indicator
  const [syncStatus, setSyncStatus] = useState<string>('Sincronizado');

  // Listen to Firebase Auth state on mount
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        setIsVerifying(true);
        try {
          const token = await user.getIdToken();
          // Immediately try to fetch OSS to check server-side authorization
          const res = await fetch('/api/oss', {
            headers: { 'Authorization': `Bearer ${token}` }
          });

          if (res.status === 403) {
            const errData = await res.json();
            setAuthError(errData.error || "Acesso não autorizado.");
            await signOut(auth);
            setVerifiedToken(null);
            setCurrentUser(null);
          } else if (!res.ok) {
            setAuthError("Erro de comunicação com o servidor de validação.");
            await signOut(auth);
            setVerifiedToken(null);
            setCurrentUser(null);
          } else {
            setVerifiedToken(token);
            setCurrentUser(user);
            const data = await res.json();
            setOssList(data);
            setAuthError(null);
          }
        } catch (err: any) {
          console.error("Token verification failed on mount/reload:", err);
          setAuthError("Falha na validação de credenciais de segurança.");
        } finally {
          setIsVerifying(false);
          setIsInitialLoading(false);
        }
      } else {
        setVerifiedToken(null);
        setCurrentUser(null);
        setIsInitialLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Fetch initial OSS list and summary metrics when verified
  useEffect(() => {
    if (verifiedToken) {
      if (ossList.length === 0) {
        loadOssList();
      }
      loadHomeSummary();
    }
  }, [verifiedToken]);

  // Load OSS lists
  const loadOssList = async () => {
    if (!verifiedToken) return;
    setIsOssLoading(true);
    setSyncStatus('Sincronizando...');
    try {
      const res = await fetch('/api/oss', {
        headers: { 'Authorization': `Bearer ${verifiedToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOssList(data);
        setSyncStatus('Sincronizado');
      } else {
        throw new Error("Erro na resposta do servidor");
      }
    } catch (err) {
      console.error("Failed to load OSS:", err);
      setSyncStatus('Erro na sincronização');
    } finally {
      setIsOssLoading(false);
    }
  };

  // Load Home Summary Metrics & Map Coordinates
  const loadHomeSummary = async () => {
    if (!verifiedToken) return;
    setIsSummaryLoading(true);
    try {
      const res = await fetch('/api/home-summary', {
        headers: { 'Authorization': `Bearer ${verifiedToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setHomeSummaryData(data);
      }
    } catch (err) {
      console.error("Failed to load home summary:", err);
    } finally {
      setIsSummaryLoading(false);
    }
  };

  // Debounced search trigger for units
  useEffect(() => {
    const trimmed = searchQuery.trim();
    if (trimmed.length >= 2 && verifiedToken) {
      setIsSearching(true);
      const delayDebounce = setTimeout(() => {
        fetch(`/api/units?search=${encodeURIComponent(trimmed)}`, {
          headers: { 'Authorization': `Bearer ${verifiedToken}` }
        })
          .then((res) => {
            if (!res.ok) throw new Error();
            return res.json();
          })
          .then((data) => {
            if (Array.isArray(data)) {
              setSearchResults(data);
            }
          })
          .catch((err) => console.error("Search API failed:", err))
          .finally(() => setIsSearching(false));
      }, 300);

      return () => clearTimeout(delayDebounce);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery, verifiedToken]);

  // Load units for selected OSS
  const handleSelectOss = async (sigla: string) => {
    if (!verifiedToken) return;
    setSelectedOssSigla(sigla);
    setCurrentView('oss');
    setSelectedUnitName(null);
    setSelectedUnitProfile(null);
    setSearchQuery(''); // Reset search when viewing OSS specifically

    setIsUnitsLoading(true);
    try {
      const res = await fetch(`/api/oss/${encodeURIComponent(sigla)}/units`, {
        headers: { 'Authorization': `Bearer ${verifiedToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOssUnits(data);
      } else {
        throw new Error();
      }
    } catch (err) {
      console.error("Failed to load OSS units:", err);
    } finally {
      setIsUnitsLoading(false);
    }
  };

  // Load detailed profile for selected Unit
  const handleSelectUnit = async (oss: string, name: string) => {
    if (!verifiedToken) return;
    setSelectedOssSigla(oss);
    setSelectedUnitName(name);
    setCurrentView('unit');
    setSelectedUnitProfile(null);

    setIsProfileLoading(true);
    try {
      const res = await fetch(`/api/units/detail?oss=${encodeURIComponent(oss)}&unidade=${encodeURIComponent(name)}`, {
        headers: { 'Authorization': `Bearer ${verifiedToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedUnitProfile(data);
      } else {
        throw new Error();
      }
    } catch (err) {
      console.error("Failed to load unit details:", err);
    } finally {
      setIsProfileLoading(false);
    }
  };

  // Trigger Google sign-in
  const handleSignIn = async () => {
    setIsVerifying(true);
    setAuthError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      const token = await user.getIdToken();

      // Verify server authorization immediately
      const res = await fetch('/api/oss', {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (res.status === 403) {
        const errData = await res.json();
        setAuthError(errData.error || "Acesso negado.");
        await signOut(auth);
        setVerifiedToken(null);
        setCurrentUser(null);
      } else if (!res.ok) {
        setAuthError("Erro na autenticação com o servidor.");
        await signOut(auth);
        setVerifiedToken(null);
        setCurrentUser(null);
      } else {
        setVerifiedToken(token);
        setCurrentUser(user);
        const data = await res.json();
        setOssList(data);
        setAuthError(null);
      }
    } catch (error: any) {
      console.error("Login popup failure:", error);
      if (error.code !== 'auth/popup-closed-by-user') {
        setAuthError(error.message || "Falha ao realizar login.");
      }
    } finally {
      setIsVerifying(false);
    }
  };

  // Handle logout
  const handleSignOut = async () => {
    setIsVerifying(true);
    try {
      await signOut(auth);
      setVerifiedToken(null);
      setCurrentUser(null);
      setOssList([]);
      setOssUnits([]);
      setSearchResults([]);
      setSelectedUnitProfile(null);
      setCurrentView('home');
      setSearchQuery('');
    } catch (err) {
      console.error("Logout failure:", err);
    } finally {
      setIsVerifying(false);
    }
  };

  // Breadcrumb navigation dispatcher
  const handleBreadcrumbNavigate = (view: 'home' | 'oss' | 'unit', ossSigla?: string, unitName?: string) => {
    if (view === 'home') {
      setCurrentView('home');
      setSelectedOssSigla(null);
      setSelectedUnitName(null);
      setSelectedUnitProfile(null);
      setSearchQuery('');
    } else if (view === 'oss' && ossSigla) {
      handleSelectOss(ossSigla);
    }
  };

  // Initializing auth wait state
  if (isInitialLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#F6F7FA]" id="app-init-spinner">
        <svg className="animate-spin h-10 w-10 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-sm font-semibold text-slate-500 mt-4 font-sans">Carregando credenciais de acesso...</p>
      </div>
    );
  }

  // Render Login state if not authenticated
  if (!currentUser || !verifiedToken) {
    return (
      <LoginScreen
        onSignIn={handleSignIn}
        error={authError}
        onSignOut={isVerifying ? null : handleSignOut}
        isVerifying={isVerifying}
        userEmail={authError && auth.currentUser ? auth.currentUser.email : null}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F6F7FA] font-sans text-slate-900" id="app-authorized-root">
      {/* Top Main Navigation Header */}
      <header className="h-16 bg-[#122A54] flex items-center justify-between px-6 shadow-md sticky top-0 z-40" id="main-header">
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between">
          {/* Logo and App Title */}
          <button 
            onClick={() => handleBreadcrumbNavigate('home')}
            className="flex items-center gap-4 text-left focus:outline-none group cursor-pointer"
            id="logo-brand-btn"
          >
            <div className="w-10 h-10 bg-white rounded flex items-center justify-center font-black text-[#122A54] text-xs leading-none text-center select-none shadow-sm transition group-hover:scale-105">
              SES<br/>PE
            </div>
            <div>
              <h1 className="text-white font-semibold text-base md:text-lg tracking-tight uppercase leading-tight">Painel de Unidades OSS — SES-PE</h1>
              <p className="text-[9px] text-slate-300 font-medium uppercase tracking-wider hidden sm:block">DGMCG - CTAI | Monitoramento Técnico de Contratos</p>
            </div>
          </button>

          {/* User Auth Info, Sync status & Logout */}
          <div className="flex items-center gap-4">
            {/* Sync State Badge */}
            <div className="hidden lg:flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-300 bg-white/5 border border-white/10 px-2 py-1 rounded">
              <RefreshCw className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>Base: {syncStatus}</span>
            </div>

            {/* User credentials */}
            <div className="flex items-center gap-3 bg-[#0B1C3B] px-3 py-1.5 rounded-lg border border-blue-900/30">
              <div className="w-7 h-7 bg-white/10 rounded flex items-center justify-center overflow-hidden text-xs text-white font-bold">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt={currentUser.displayName || ''} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="w-4 h-4" />
                )}
              </div>
              <div className="text-left hidden md:block">
                <p className="text-xs font-bold text-white leading-none truncate max-w-[150px]" title={currentUser.displayName || ''}>
                  {currentUser.displayName || 'Servidor Interno'}
                </p>
                <p className="text-[9px] text-slate-400 leading-none mt-1 truncate max-w-[150px]" title={currentUser.email || ''}>
                  {currentUser.email}
                </p>
              </div>
              <button
                onClick={handleSignOut}
                className="p-1 text-slate-300 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                title="Sair da conta"
                id="header-logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb section */}
      {currentView !== 'home' && (
        <Breadcrumb
          ossSigla={selectedOssSigla || undefined}
          unitName={selectedUnitName || undefined}
          onNavigate={handleBreadcrumbNavigate}
        />
      )}

      {/* Main body viewport */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-6 space-y-6" id="main-viewport">
        
        {/* 1. FAIXA DE RESUMO QUANTITATIVO (Topo da página inicial) */}
        {currentView === 'home' && (
          <SummaryBar
            summaryData={homeSummaryData?.summary || null}
            isLoading={isSummaryLoading}
          />
        )}

        {/* 2. GLOBAL SEARCH BAR (Página Inicial) */}
        {currentView === 'home' && (
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3" id="global-search-container">
            <label htmlFor="search-input" className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Consultar Unidade de Saúde (Live)
            </label>
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input
                id="search-input"
                type="text"
                placeholder="Digite pelo menos 2 caracteres do nome do Hospital, UPA ou UPAE..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-[#122A54] focus:bg-white transition"
              />
              {isSearching && (
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2">
                  <svg className="animate-spin h-4 w-4 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. CONTROLE DE ALTERNÂNCIA ("Ver por OSS" vs "Ver no mapa") */}
        {currentView === 'home' && searchQuery.trim().length < 2 && (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3" id="home-view-toggle-bar">
            <div>
              <h2 className="text-base font-bold text-slate-950 tracking-tight">
                {homeViewMode === 'oss' ? 'Organizações Sociais de Saúde (OSS)' : 'Visualização Espacial no Mapa'}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {homeViewMode === 'oss'
                  ? 'Selecione uma entidade para visualizar suas unidades e relatórios'
                  : 'Geolocalização das unidades de saúde da rede estadual em Pernambuco'}
              </p>
            </div>

            {/* Segmented Control */}
            <div className="bg-slate-200/80 p-1 rounded-xl flex items-center gap-1 shrink-0 self-start sm:self-auto" id="view-mode-segmented-control">
              <button
                onClick={() => setHomeViewMode('oss')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  homeViewMode === 'oss'
                    ? 'bg-white text-[#122A54] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                id="toggle-view-oss-btn"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Ver por OSS</span>
              </button>

              <button
                onClick={() => setHomeViewMode('map')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  homeViewMode === 'map'
                    ? 'bg-white text-[#122A54] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                id="toggle-view-map-btn"
              >
                <MapPin className="w-3.5 h-3.5 text-red-600" />
                <span>Ver no mapa</span>
              </button>
            </div>
          </div>
        )}

        {/* --- DYNAMIC VIEWPORT DISPATCHER --- */}
        <div id="dynamic-viewport-dispatcher">
          {searchQuery.trim().length >= 2 && currentView === 'home' ? (
            /* 1. Unit Search View (Active Search Query) */
            <UnitsList
              units={searchResults}
              title={`Resultados da busca por: "${searchQuery}"`}
              subtitle="Unidades localizadas na base live consolidada do DGMCG."
              onSelectUnit={handleSelectUnit}
              isLoading={isSearching}
            />
          ) : currentView === 'home' ? (
            homeViewMode === 'oss' ? (
              /* 2a. OSS Dashboard Cards Grid */
              <OssGrid
                ossList={ossList}
                onSelectOss={handleSelectOss}
                isLoading={isOssLoading}
              />
            ) : (
              /* 2b. Interactive Map of Pernambuco */
              <PernambucoMap
                units={homeSummaryData?.mapUnits || []}
                onSelectUnit={handleSelectUnit}
                isLoading={isSummaryLoading}
              />
            )
          ) : currentView === 'oss' ? (
            /* 3. OSS Unit list view */
            <UnitsList
              units={ossUnits}
              title={`Unidades geridas por: ${selectedOssSigla}`}
              subtitle="Acompanhamento operacional e diagnósticos de monitoramento."
              onSelectUnit={handleSelectUnit}
              onBackToHome={() => handleBreadcrumbNavigate('home')}
              isLoading={isUnitsLoading}
            />
          ) : (
            /* 4. Complete Unit Profile Dashboard */
            <ErrorBoundary
              fallbackTitle="Erro ao carregar o Perfil da Unidade"
              onReset={() => handleBreadcrumbNavigate('oss', selectedOssSigla || undefined)}
            >
              <UnitProfile
                profile={selectedUnitProfile}
                isLoading={isProfileLoading}
                onBack={() => handleBreadcrumbNavigate('oss', selectedOssSigla || undefined)}
              />
            </ErrorBoundary>
          )}
        </div>

      </main>

      {/* FOOTER STATUS */}
      <footer className="h-8 bg-slate-200 border-t border-slate-300 flex items-center px-8 justify-between text-[10px] text-slate-600 shrink-0 uppercase tracking-widest font-sans" id="main-footer">
        <span>DGMCG / CTAI - Monitoramento Técnico</span>
        <span className="hidden sm:inline">Base de Dados: BD Unidades OSS - Consolidado</span>
        <span className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Conectado via Google Sheets API
        </span>
      </footer>
    </div>
  );
}
