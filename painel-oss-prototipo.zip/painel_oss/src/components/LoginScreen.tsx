import React from 'react';
import { Shield, AlertCircle, LogOut } from 'lucide-react';

interface LoginScreenProps {
  onSignIn: () => void;
  error: string | null;
  onSignOut: (() => void) | null;
  isVerifying: boolean;
  userEmail: string | null;
}

export default function LoginScreen({ onSignIn, error, onSignOut, isVerifying, userEmail }: LoginScreenProps) {
  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F6F7FA] font-sans text-slate-900" id="login-screen-root">
      {/* HEADER */}
      <header className="h-16 bg-[#122A54] flex items-center justify-between px-8 shrink-0 shadow-md">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-white rounded flex items-center justify-center font-black text-[#122A54] text-xs leading-none text-center select-none shadow-sm">
            SES<br/>PE
          </div>
          <h1 className="text-white font-semibold text-lg tracking-tight uppercase">Painel de Unidades OSS — SES-PE</h1>
        </div>
        <div className="hidden md:flex items-center gap-4 text-right">
          <div>
            <p className="text-xs font-bold text-white uppercase tracking-wider">DGMCG / CTAI</p>
            <p className="text-[10px] text-slate-300">Monitoramento Técnico de Contratos</p>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow flex items-center justify-center p-6">
        <div className="w-full max-w-md bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden" id="login-card">
          {/* Accent Header */}
          <div className="bg-[#122A54] p-6 text-center text-white relative">
            <div className="w-12 h-12 bg-white/10 rounded flex items-center justify-center mx-auto mb-3">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-lg font-bold tracking-tight uppercase">Acesso ao Painel</h2>
            <p className="text-xs text-slate-300 mt-1">Acompanhamento Técnico e Gerencial</p>
          </div>

          <div className="p-6 space-y-6">
            {error ? (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg space-y-3 text-sm text-red-800" id="login-error-container">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-900">Acesso Restrito</h3>
                    <p className="text-xs text-red-700 mt-1">{error}</p>
                  </div>
                </div>
                
                {userEmail && (
                  <div className="bg-white/60 p-2 rounded border border-red-100 text-xs text-red-900 font-mono text-center">
                    E-mail atual: {userEmail}
                  </div>
                )}

                {onSignOut && (
                  <button
                    onClick={onSignOut}
                    className="w-full py-2 bg-red-100 hover:bg-red-200 text-red-900 font-medium rounded transition flex items-center justify-center space-x-2 text-xs"
                    id="sign-out-btn"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Usar outra conta</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4 text-center">
                <p className="text-xs text-slate-600 leading-relaxed">
                  Bem-vindo à ferramenta de monitoramento consolidada da equipe interna <strong>DGMCG/CTAI</strong>. 
                  Conecte-se para analisar leitos, metas de produção, recursos tecnológicos e pareceres das unidades geridas.
                </p>

                <div className="bg-slate-50 p-4 rounded border border-slate-100 text-left space-y-2">
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Diretrizes de Segurança</h4>
                  <ul className="text-xs text-slate-600 list-disc list-inside space-y-1.5 font-medium">
                    <li>Contas funcionais <span className="font-semibold text-[#122A54]">@ses.pe.gov.br</span></li>
                    <li>Permissões liberadas pela equipe de TI/CTAI</li>
                  </ul>
                </div>
              </div>
            )}

            {!userEmail && (
              <button
                onClick={onSignIn}
                disabled={isVerifying}
                className="w-full flex items-center justify-center space-x-3 py-2.5 px-4 border border-slate-200 rounded text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#122A54] transition disabled:opacity-50 uppercase tracking-wider shadow-xs cursor-pointer"
                id="sign-in-google-btn"
              >
                {isVerifying ? (
                  <svg className="animate-spin h-4 w-4 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                )}
                <span>{isVerifying ? 'Verificando...' : 'Autenticar via Google'}</span>
              </button>
            )}
          </div>
        </div>
      </main>

      {/* FOOTER STATUS */}
      <footer className="h-8 bg-slate-200 border-t border-slate-300 flex items-center px-8 justify-between text-[10px] text-slate-600 shrink-0 uppercase tracking-widest font-sans">
        <span>DGMCG / CTAI - Monitoramento Técnico</span>
        <span className="hidden sm:inline">Base de Dados Consolidada</span>
        <span className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Conectado
        </span>
      </footer>
    </div>
  );
}
