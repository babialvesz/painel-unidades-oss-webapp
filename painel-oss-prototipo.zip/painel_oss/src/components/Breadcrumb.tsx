import React from 'react';
import { ChevronRight, Home, Shield, Activity } from 'lucide-react';

interface BreadcrumbProps {
  ossSigla?: string;
  unitName?: string;
  onNavigate: (view: 'home' | 'oss' | 'unit', ossSigla?: string, unitName?: string) => void;
}

export default function Breadcrumb({ ossSigla, unitName, onNavigate }: BreadcrumbProps) {
  return (
    <nav className="h-10 bg-white border-b border-slate-200 flex items-center px-6 text-xs text-slate-500 shrink-0 shadow-sm" aria-label="Breadcrumb" id="app-breadcrumb">
      <div className="max-w-7xl mx-auto w-full flex items-center space-x-1">
        <button
          onClick={() => onNavigate('home')}
          className="hover:text-[#122A54] cursor-pointer font-medium focus:outline-none transition-colors"
          id="breadcrumb-home"
        >
          Todas as OSS
        </button>

        {ossSigla && (
          <>
            <span className="text-slate-300 mx-1.5 font-light">/</span>
            <button
              onClick={() => onNavigate('oss', ossSigla)}
              className={`hover:text-[#122A54] cursor-pointer focus:outline-none transition-colors uppercase font-medium ${!unitName ? 'text-[#122A54] font-semibold' : ''}`}
              id={`breadcrumb-oss-${ossSigla}`}
            >
              {ossSigla}
            </button>
          </>
        )}

        {unitName && (
          <>
            <span className="text-slate-300 mx-1.5 font-light">/</span>
            <span className="text-[#122A54] font-semibold uppercase truncate" id="breadcrumb-unit-name">
              {unitName}
            </span>
          </>
        )}
      </div>
    </nav>
  );
}
