import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import { MapUnit } from '../types';
import { MapPin, Filter, Layers } from 'lucide-react';

interface PernambucoMapProps {
  units: MapUnit[];
  onSelectUnit: (oss: string, name: string) => void;
  isLoading?: boolean;
}

export default function PernambucoMap({ units, onSelectUnit, isLoading }: PernambucoMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const clusterGroupRef = useRef<any>(null);
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('TODOS');

  // Helpers for Type Colors & Labels
  const getTypeMeta = (tipoStr: string) => {
    const t = tipoStr.toUpperCase().trim();
    if (t.includes('HOSPITAL')) {
      return { key: 'HOSPITAL', label: 'Hospital', bg: '#122A54', border: '#0B1C3B' };
    }
    if (t.includes('UPAE') || t === 'UPAE') {
      return { key: 'UPAE', label: 'UPAE', bg: '#D97706', border: '#B45309' };
    }
    if (t.includes('UPA')) {
      return { key: 'UPA', label: 'UPA', bg: '#059669', border: '#047857' };
    }
    if (t.includes('CARRETA')) {
      return { key: 'CARRETA', label: 'Carreta', bg: '#7C3AED', border: '#6D28D9' };
    }
    return { key: 'OUTROS', label: 'Outros', bg: '#475569', border: '#334155' };
  };

  // Filter valid coordinates (excluding Carretas as mobile units)
  const validUnits = React.useMemo(() => {
    return units.filter(
      (u) =>
        u.latitude !== null &&
        u.longitude !== null &&
        !isNaN(u.latitude) &&
        !isNaN(u.longitude) &&
        u.latitude < 0 && // Pernambuco coordinates are negative lat/long
        u.longitude < 0 &&
        !u.tipo.toUpperCase().includes('CARRETA')
    );
  }, [units]);

  // Filtered units by type selection
  const filteredUnits = React.useMemo(() => {
    if (selectedTypeFilter === 'TODOS') return validUnits;
    return validUnits.filter((u) => {
      const meta = getTypeMeta(u.tipo);
      return meta.key === selectedTypeFilter;
    });
  }, [validUnits, selectedTypeFilter]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Center Pernambuco (~ -8.35, -37.8, zoom 8)
      const map = L.map(mapContainerRef.current, {
        center: [-8.35, -37.8],
        zoom: 8,
        zoomControl: true,
        scrollWheelZoom: true,
      });

      // OpenStreetMap Tile Layer with obligatory attribution
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
        maxZoom: 18,
      }).addTo(map);

      mapInstanceRef.current = map;

      // Force recalculation of container size after mounting in container/toggle
      setTimeout(() => {
        map.invalidateSize();
        map.setView([-8.35, -37.8], 8);
      }, 150);

      // ResizeObserver to continuously handle container layout shifts
      const resizeObserver = new ResizeObserver(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      });
      resizeObserver.observe(mapContainerRef.current);

      // Event delegation for "Ver perfil" buttons inside Leaflet HTML popups
      const container = mapContainerRef.current;
      const handlePopupClick = (e: MouseEvent) => {
        const target = e.target as HTMLElement;
        const btn = target.closest('.btn-ver-perfil-map') as HTMLButtonElement | null;
        if (btn) {
          const oss = btn.getAttribute('data-oss');
          const unitName = btn.getAttribute('data-unidade');
          if (oss && unitName) {
            onSelectUnit(oss, unitName);
          }
        }
      };

      container.addEventListener('click', handlePopupClick);

      return () => {
        resizeObserver.disconnect();
        container.removeEventListener('click', handlePopupClick);
      };
    }
  }, [onSelectUnit]);

  // Render Markers on Filter or Units Change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear previous cluster group
    if (clusterGroupRef.current) {
      map.removeLayer(clusterGroupRef.current);
      clusterGroupRef.current = null;
    }

    if (filteredUnits.length === 0) return;

    // Create marker cluster group
    const clusterGroup = (L as any).markerClusterGroup({
      showCoverageOnHover: false,
      maxClusterRadius: 35,
      spiderfyOnMaxZoom: true,
      zoomToBoundsOnClick: true,
      iconCreateFunction: (cluster: any) => {
        const childCount = cluster.getChildCount();
        return L.divIcon({
          html: `<div style="background-color: #122A54; color: white; border: 2px solid white; border-radius: 50%; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.25);">${childCount}</div>`,
          className: 'custom-cluster-icon',
          iconSize: [34, 34],
        });
      },
    });

    const bounds = L.latLngBounds([]);

    filteredUnits.forEach((unit) => {
      if (unit.latitude === null || unit.longitude === null) return;

      const meta = getTypeMeta(unit.tipo);
      const initialLetter = meta.label.charAt(0).toUpperCase();

      // Custom DivIcon vector marker
      const customIcon = L.divIcon({
        className: 'custom-unit-marker',
        html: `
          <div style="
            background-color: ${meta.bg};
            color: #ffffff;
            border: 2px solid #ffffff;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 11px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.3);
            cursor: pointer;
            transition: transform 0.15s ease;
          " title="${unit.unidade}">
            ${initialLetter}
          </div>
        `,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
        popupAnchor: [0, -15],
      });

      const marker = L.marker([unit.latitude, unit.longitude], { icon: customIcon });

      // Popup Content
      const popupHtml = `
        <div style="font-family: inherit; min-width: 210px; padding: 2px;">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px;">
            <span style="background-color: ${meta.bg}; color: #ffffff; font-size: 10px; font-weight: 800; text-transform: uppercase; padding: 2px 8px; border-radius: 4px; letter-spacing: 0.5px;">
              ${meta.label}
            </span>
            <span style="font-size: 10px; font-weight: 600; color: #64748b; text-transform: uppercase;">
              ${unit.cidade}
            </span>
          </div>
          <h4 style="font-size: 13px; font-weight: 700; color: #0f172a; margin: 0 0 6px 0; line-height: 1.3;">
            ${unit.unidade}
          </h4>
          <p style="font-size: 11px; color: #475569; margin: 0 0 10px 0; font-weight: 500;">
            OSS: <strong style="color: #0f172a;">${unit.oss}</strong>
          </p>
          <button
            data-oss="${unit.oss}"
            data-unidade="${unit.unidade}"
            class="btn-ver-perfil-map"
            style="
              width: 100%;
              padding: 7px 12px;
              background-color: #122A54;
              color: #ffffff;
              border: none;
              border-radius: 6px;
              font-size: 11px;
              font-weight: 700;
              cursor: pointer;
              transition: background-color 0.15s ease;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 4px;
            "
          >
            Ver perfil &rarr;
          </button>
        </div>
      `;

      marker.bindPopup(popupHtml, {
        closeButton: true,
        className: 'custom-leaflet-popup',
      });

      clusterGroup.addLayer(marker);
      bounds.extend([unit.latitude, unit.longitude]);
    });

    map.addLayer(clusterGroup);
    clusterGroupRef.current = clusterGroup;

    // Recalculate dimensions and fit bounds
    setTimeout(() => {
      map.invalidateSize();
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 12 });
      } else {
        map.setView([-8.35, -37.8], 8);
      }
    }, 100);
  }, [filteredUnits]);

  // Clean map instance on unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm" id="pernambuco-map-card">
      {/* Map Header & Controls */}
      <div className="px-5 py-4 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#122A54]/10 text-[#122A54] flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-sm tracking-tight">Mapa de Unidades de Saúde de Pernambuco</h3>
            <p className="text-xs text-slate-500 font-medium">
              {filteredUnits.length} de {validUnits.length} unidades com geolocalização plotadas
            </p>
          </div>
        </div>

        {/* Filter Badges / Controls */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'TODOS', label: 'Todas' },
            { id: 'HOSPITAL', label: 'Hospitais' },
            { id: 'UPA', label: 'UPAs' },
            { id: 'UPAE', label: 'UPAEs' },
          ].map((type) => {
            const isSelected = selectedTypeFilter === type.id;
            return (
              <button
                key={type.id}
                onClick={() => setSelectedTypeFilter(type.id)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? 'bg-[#122A54] text-white shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                {type.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Map Container */}
      <div className="relative">
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 z-20 flex flex-col items-center justify-center space-y-2">
            <svg className="animate-spin h-8 w-8 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="text-xs font-semibold text-slate-600">Carregando mapa interativo...</p>
          </div>
        )}

        <div ref={mapContainerRef} className="w-full h-[520px] z-0" id="leaflet-map-canvas" />

        {/* Legend Overlay at bottom right */}
        <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm border border-slate-200/90 p-3 rounded-lg shadow-md z-10 text-[11px] space-y-1.5 hidden sm:block">
          <span className="font-bold text-slate-800 uppercase tracking-wider text-[10px] block mb-1">Legenda por Tipo</span>
          <div className="flex items-center gap-3 font-medium text-slate-700">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#122A54] inline-block border border-white shadow-2xs"></span>
              <span>Hospital</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#059669] inline-block border border-white shadow-2xs"></span>
              <span>UPA</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#D97706] inline-block border border-white shadow-2xs"></span>
              <span>UPAE</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
