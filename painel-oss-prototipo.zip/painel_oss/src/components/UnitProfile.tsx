import React from 'react';
import { UnitProfileData } from '../types';
import ErrorBoundary from './ErrorBoundary';
import { 
  Building2, Activity, Shield, AlertTriangle, 
  Database, Bed, Calendar, FileText,
  DollarSign, ArrowRight, Search, FileCheck, TrendingUp
} from 'lucide-react';

interface UnitProfileProps {
  profile: UnitProfileData | null;
  isLoading: boolean;
  onBack: () => void;
}

export default function UnitProfile({ profile, isLoading, onBack }: UnitProfileProps) {
  const [activeTab, setActiveTab] = React.useState<'visao-geral' | 'desempenho' | 'financeiro' | 'pareceres'>('visao-geral');
  const [selectedPeriod, setSelectedPeriod] = React.useState<string>('');
  const [parecerSearch, setParecerSearch] = React.useState<string>('');

  // Safe extraction with explicit defaults to prevent undefined property crashes
  const identificacao = profile?.identificacao || ({} as any);
  const tic = profile?.tic || null;
  const leitos = profile?.leitos || null;
  const pareceres = Array.isArray(profile?.pareceres) ? profile.pareceres : [];
  const producao = Array.isArray(profile?.producao) ? profile.producao : [];
  const analiseDesempenho = profile?.analiseDesempenho || null;
  const metasSugeridas = Array.isArray(profile?.metasSugeridas) ? profile.metasSugeridas : [];
  const repasses = Array.isArray(profile?.repasses) ? profile.repasses : [];
  const apontamentosDesconto = Array.isArray(profile?.apontamentosDesconto) ? profile.apontamentosDesconto : [];
  const especialidadesInfo = profile?.especialidadesInfo || null;

  const groupedEspecialidades: Record<string, string[]> | null = React.useMemo(() => {
    if (!especialidadesInfo || !Array.isArray(especialidadesInfo.lista) || especialidadesInfo.lista.length === 0) return null;

    const groups: Record<string, string[]> = {};
    especialidadesInfo.lista.forEach(item => {
      if (!item) return;
      const t = item.tipo ? String(item.tipo).trim() : 'Geral';
      const spec = item.especialidade ? String(item.especialidade).trim() : '';
      if (!spec) return;
      if (!groups[t]) groups[t] = [];
      if (!groups[t].includes(spec)) {
        groups[t].push(spec);
      }
    });
    return groups;
  }, [especialidadesInfo]);

  const apontamentosDescontoList = React.useMemo(() => {
    if (Array.isArray(apontamentosDesconto) && apontamentosDesconto.length > 0) {
      return apontamentosDesconto;
    }
    if (!Array.isArray(pareceres) || pareceres.length === 0) return [];
    return pareceres
      .filter(p => {
        if (!p) return false;
        const val = String(p.temDescontoFinanceiro || '').toLowerCase().trim();
        return val === 'sim' || val.startsWith('sim');
      })
      .map(p => ({
        ano: String(p.ano || ''),
        trimestre: String(p.trimestre || ''),
        categoriaApontamento: String(p.categoriaApontamento || ''),
        percentualValor: String(p.percentualValor || ''),
        temDescontoFinanceiro: String(p.temDescontoFinanceiro || 'Sim')
      }));
  }, [apontamentosDesconto, pareceres]);

  // Indicator 1: Situação Contratual
  const isVigente = React.useMemo(() => {
    const sit = String(identificacao?.situacao || '').toUpperCase();
    return sit.includes('VIGENTE') || sit.includes('ATIVO');
  }, [identificacao?.situacao]);

  // Indicator 2: Nº de Apontamentos de Desconto Financeiro
  const descontoCount = React.useMemo(() => {
    return apontamentosDescontoList.length;
  }, [apontamentosDescontoList]);

  // Indicator 3: Nº de Debilidades registradas na Análise de Desempenho
  const debilidadesCount = React.useMemo(() => {
    if (!analiseDesempenho || !analiseDesempenho.debilidades) return 0;
    const deb = String(analiseDesempenho.debilidades || '').trim().toLowerCase();
    if (!deb || deb.includes('nenhuma debilidade') || deb === '-' || deb === 'sem dado' || deb === 'nenhum ponto') return 0;
    const lines = deb.split(/[\n;]/).filter(l => l.trim().length > 3);
    return lines.length > 0 ? lines.length : 1;
  }, [analiseDesempenho]);

  // Indicator 4: Saldo a pagar mais recente (do card de Repasses Financeiros)
  const saldoAPagarMaisRecente = React.useMemo(() => {
    if (!Array.isArray(repasses) || repasses.length === 0) return '-';
    const latest = repasses[0];
    if (!latest) return '-';
    const saldo = (latest.saldoAPagarOss && latest.saldoAPagarOss !== '-') 
      ? latest.saldoAPagarOss 
      : (latest.saldoAPagarProvisaoFutura && latest.saldoAPagarProvisaoFutura !== '-')
        ? latest.saldoAPagarProvisaoFutura
        : '-';
    return String(saldo);
  }, [repasses]);

  const periods = React.useMemo(() => {
    const uniqueKeys = new Set<string>();
    const list: { key: string; ano: string; mes: string; monthNum: number }[] = [];
    
    const monthsMap: Record<string, number> = { 
      'janeiro': 1, 'fevereiro': 2, 'marco': 3, 'março': 3, 'abril': 4, 'maio': 5, 
      'junho': 6, 'julho': 7, 'agosto': 8, 'setembro': 9, 'outubro': 10, 'novembro': 11, 'dezembro': 12 
    };

    if (Array.isArray(producao)) {
      producao.forEach(p => {
        if (!p || p.ano === undefined || p.ano === null || p.mes === undefined || p.mes === null) return;
        const anoStr = String(p.ano).trim();
        const mesStr = String(p.mes).trim();
        if (!anoStr || !mesStr) return;
        const mesLower = mesStr.toLowerCase();
        const key = `${anoStr}-${mesLower}`;
        if (!uniqueKeys.has(key)) {
          uniqueKeys.add(key);
          list.push({
            key,
            ano: anoStr,
            mes: mesStr,
            monthNum: monthsMap[mesLower] || 0
          });
        }
      });
    }

    return list.sort((a, b) => {
      const yearA = parseInt(a.ano, 10) || 0;
      const yearB = parseInt(b.ano, 10) || 0;
      if (yearA !== yearB) return yearB - yearA;
      return b.monthNum - a.monthNum;
    });
  }, [producao]);

  // Auto-select latest period if empty
  React.useEffect(() => {
    if (periods.length > 0) {
      if (!selectedPeriod || !periods.some(p => p.key === selectedPeriod)) {
        setSelectedPeriod(periods[0].key);
      }
    }
  }, [periods, selectedPeriod]);

  const filteredProducao = React.useMemo(() => {
    if (!selectedPeriod || !Array.isArray(producao)) return [];
    return producao.filter(p => {
      if (!p || p.ano === undefined || p.ano === null || p.mes === undefined || p.mes === null) return false;
      const anoStr = String(p.ano).trim();
      const mesStr = String(p.mes).trim();
      const key = `${anoStr}-${mesStr.toLowerCase()}`;
      if (key !== selectedPeriod) return false;
      const metaVal = Number(p.meta) || 0;
      const prodVal = Number(p.producao) || 0;
      return metaVal !== 0 || prodVal !== 0;
    });
  }, [producao, selectedPeriod]);

  // Filtered Pareceres for search in Pareceres tab
  const filteredPareceres = React.useMemo(() => {
    if (!Array.isArray(pareceres)) return [];
    if (!parecerSearch.trim()) return pareceres;
    const q = parecerSearch.toLowerCase().trim();
    return pareceres.filter(p => {
      if (!p) return false;
      return (
        String(p.trimestre || '').toLowerCase().includes(q) ||
        String(p.ano || '').toLowerCase().includes(q) ||
        String(p.numeroParecer || '').toLowerCase().includes(q) ||
        String(p.resumoMetas || '').toLowerCase().includes(q) ||
        String(p.pendenciasDescontos || '').toLowerCase().includes(q) ||
        String(p.observacoes || '').toLowerCase().includes(q)
      );
    });
  }, [pareceres, parecerSearch]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-32 space-y-4" id="profile-loading">
        <svg className="animate-spin h-10 w-10 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-sm font-semibold text-slate-500">Buscando perfil completo da unidade...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-20 max-w-md mx-auto space-y-4" id="profile-not-found">
        <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
        <h3 className="text-lg font-bold text-slate-950">Unidade não localizada</h3>
        <p className="text-sm text-slate-500">
          Não foi possível sincronizar as informações para a unidade de saúde selecionada. Por favor, retorne e tente novamente.
        </p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-[#122A54] hover:bg-[#0B1C3B] text-white text-sm font-semibold rounded-lg transition"
        >
          Voltar para unidades
        </button>
      </div>
    );
  }

  const tabs = [
    { id: 'visao-geral', label: 'Visão Geral', icon: Building2 },
    { id: 'desempenho', label: 'Desempenho', icon: TrendingUp },
    { id: 'financeiro', label: 'Financeiro', icon: DollarSign },
    { id: 'pareceres', label: 'Pareceres', icon: Shield },
  ] as const;

  return (
    <ErrorBoundary fallbackTitle="Erro ao exibir perfil da unidade" onReset={onBack}>
      <div className="space-y-6 font-sans text-slate-900" id="unit-profile-container">
        <style dangerouslySetInnerHTML={{__html: `
          .custom-scrollbar {
            scrollbar-width: thin;
            scrollbar-color: rgba(18, 42, 84, 0.25) rgba(241, 245, 249, 0.05);
          }
          .custom-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 5px;
            display: block !important;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: rgba(241, 245, 249, 0.4);
            border-radius: 9999px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.5);
            border-radius: 9999px;
            border: 1px solid rgba(241, 245, 249, 0.4);
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(18, 42, 84, 0.4);
          }
        `}} />

        {/* HEADER CARD DA UNIDADE */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4" id="profile-header-card">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex flex-wrap gap-1.5">
                <span className="px-2 py-0.5 bg-[#122A54]/10 text-[#122A54] text-[9px] font-bold rounded uppercase tracking-wider font-mono">
                  OSS: {identificacao.oss || 'N/A'}
                </span>
                <span className="px-2 py-0.5 bg-slate-100 text-slate-600 text-[9px] font-bold rounded uppercase tracking-wider">
                  {identificacao.tipo || 'Sem Tipo'}
                </span>
                <span className="px-2 py-0.5 bg-[#122A54]/5 text-slate-600 text-[9px] font-bold rounded uppercase tracking-wider">
                  {identificacao.cidade || 'Sem Cidade'}
                </span>
              </div>
              <h1 className="text-lg md:text-xl font-extrabold text-slate-900 tracking-tight uppercase leading-tight" id="profile-title">
                {identificacao.unidade || 'Unidade sem Nome'}
              </h1>
            </div>
            
            <div className="text-left md:text-right shrink-0">
              <span className={`inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                isVigente
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`} id="profile-status">
                <span className={`w-1.5 h-1.5 rounded-full ${
                  isVigente
                    ? 'bg-emerald-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]' 
                    : 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]'
                }`}></span>
                <span>{identificacao.situacao || 'Sem Situação'}</span>
              </span>
              <p className="text-[10px] text-slate-400 uppercase font-medium mt-1">Situação Contratual</p>
            </div>
          </div>
        </div>

        {/* FAIXA DE RESUMO (Sempre Visível) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3" id="profile-summary-bar">
          {/* Indicador 1: Situação Contratual */}
          <button
            onClick={() => setActiveTab('visao-geral')}
            className="bg-white border border-slate-200 hover:border-[#122A54] hover:shadow-md rounded-xl p-3.5 text-left transition-all cursor-pointer group flex flex-col justify-between"
            id="summary-item-situacao"
          >
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">Situação Contratual</span>
              <Building2 className="w-4 h-4 text-slate-400 group-hover:text-[#122A54] shrink-0 transition-colors" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full shrink-0 ${isVigente ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                <span className="text-xs font-extrabold text-slate-800 truncate uppercase">
                  {identificacao.situacao || 'Sem Situação'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium group-hover:text-[#122A54] flex items-center gap-1 transition-colors">
                <span>Ver Visão Geral</span>
                <ArrowRight className="w-3 h-3" />
              </p>
            </div>
          </button>

          {/* Indicador 2: Apontamentos de Desconto Financeiro */}
          <button
            onClick={() => setActiveTab('financeiro')}
            className="bg-white border border-slate-200 hover:border-[#122A54] hover:shadow-md rounded-xl p-3.5 text-left transition-all cursor-pointer group flex flex-col justify-between"
            id="summary-item-descontos"
          >
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">Apontamentos Desconto</span>
              <FileText className="w-4 h-4 text-slate-400 group-hover:text-[#122A54] shrink-0 transition-colors" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className={`text-sm font-black font-mono ${descontoCount > 0 ? 'text-amber-600' : 'text-slate-800'}`}>
                  {descontoCount}
                </span>
                <span className={`text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                  descontoCount > 0 ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'
                }`}>
                  {descontoCount === 0 ? 'Nenhum' : descontoCount === 1 ? 'Registrado' : 'Registrados'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium group-hover:text-[#122A54] flex items-center gap-1 transition-colors">
                <span>Ver Financeiro</span>
                <ArrowRight className="w-3 h-3" />
              </p>
            </div>
          </button>

          {/* Indicador 3: Debilidades na Análise de Desempenho */}
          <button
            onClick={() => setActiveTab('desempenho')}
            className="bg-white border border-slate-200 hover:border-[#122A54] hover:shadow-md rounded-xl p-3.5 text-left transition-all cursor-pointer group flex flex-col justify-between"
            id="summary-item-debilidades"
          >
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">Debilidades (CTAI)</span>
              <Activity className="w-4 h-4 text-slate-400 group-hover:text-[#122A54] shrink-0 transition-colors" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className={`text-sm font-black font-mono ${debilidadesCount > 0 ? 'text-amber-600' : 'text-emerald-700'}`}>
                  {debilidadesCount}
                </span>
                <span className={`text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                  debilidadesCount > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-50 text-emerald-800 border border-emerald-100'
                }`}>
                  {debilidadesCount === 0 ? 'Sem Debilidades' : debilidadesCount === 1 ? 'Registrada' : 'Registradas'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium group-hover:text-[#122A54] flex items-center gap-1 transition-colors">
                <span>Ver Desempenho</span>
                <ArrowRight className="w-3 h-3" />
              </p>
            </div>
          </button>

          {/* Indicador 4: Saldo a Pagar Mais Recente */}
          <button
            onClick={() => setActiveTab('financeiro')}
            className="bg-white border border-slate-200 hover:border-[#122A54] hover:shadow-md rounded-xl p-3.5 text-left transition-all cursor-pointer group flex flex-col justify-between"
            id="summary-item-saldo"
          >
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">Saldo a Pagar Recente</span>
              <DollarSign className="w-4 h-4 text-slate-400 group-hover:text-[#122A54] shrink-0 transition-colors" />
            </div>
            <div className="space-y-1">
              <div className="text-xs font-black font-mono text-[#122A54] truncate" title={saldoAPagarMaisRecente}>
                {saldoAPagarMaisRecente}
              </div>
              <p className="text-[10px] text-slate-400 font-medium group-hover:text-[#122A54] flex items-center gap-1 transition-colors">
                <span>Ref: {repasses?.[0]?.competencia || 'Recente'}</span>
                <ArrowRight className="w-3 h-3" />
              </p>
            </div>
          </button>
        </div>

        {/* BARRA DE NAVEGAÇÃO POR ABAS (TAB STRIP) */}
        <div className="bg-white border border-slate-200 rounded-xl p-1.5 shadow-sm flex flex-wrap gap-1.5" id="profile-tab-strip">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#122A54] text-white shadow-sm'
                    : 'text-slate-600 hover:text-[#122A54] hover:bg-slate-100/80'
                }`}
                id={`tab-btn-${tab.id}`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-blue-300' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* --- CONTEÚDO DAS ABAS --- */}

        {/* 1ª ABA: VISÃO GERAL */}
        {activeTab === 'visao-geral' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start" id="tab-content-visao-geral">
            {/* Coluna Esquerda: Identificação & Tecnologia */}
            <div className="space-y-6">
              {/* Card: Identificação */}
              <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-slate-400" />
                    Identificação da Unidade
                  </h2>
                  <div className={`w-2 h-2 rounded-full ${isVigente ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                </div>
                
                <div className="space-y-3.5">
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-medium">Contrato de Gestão</p>
                    <p className="text-xs font-semibold text-slate-800">{identificacao.contrato || 'Sem dado'}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-medium">CNPJ Unidade</p>
                      <p className="text-xs font-medium font-mono text-slate-800 truncate" title={identificacao.cnpjUnidade}>{identificacao.cnpjUnidade || 'Sem dado'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-medium">CNES</p>
                      <p className="text-xs font-medium font-mono text-slate-800">{identificacao.cnes || 'Sem dado'}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-medium">Região / GERES</p>
                    <p className="text-xs font-semibold text-slate-800">
                      {identificacao.macro && identificacao.geres ? `Macro ${identificacao.macro} - ${identificacao.geres}` : 'Sem dado'}
                    </p>
                  </div>
                  <div className="pt-2 border-t border-slate-100">
                    <p className="text-[10px] text-slate-400 uppercase font-medium">Endereço Completo</p>
                    <p className="text-xs text-slate-600 leading-relaxed font-medium">{identificacao.enderecoCompleto || 'Sem endereço'}</p>
                  </div>
                </div>
              </section>

              {/* Card: Tecnologia (TIC) */}
              <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <Database className="w-4 h-4 text-slate-400" />
                    Tecnologia da Informação (TIC)
                  </h2>
                </div>

                {tic ? (
                  <div className="space-y-3.5">
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-medium">Sistema Utilizado</p>
                      <p className="text-xs font-bold text-[#122A54] uppercase tracking-wide">{tic.sistemaUtilizado || 'Sem sistema'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-medium">Técnico Responsável</p>
                      <p className="text-xs font-semibold text-slate-800">{tic.tecnicoResponsavel || 'Sem técnico designado'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-medium">Contato Responsável</p>
                      <p className="text-xs font-bold text-blue-600 font-mono">{tic.contatoResponsavel || 'Sem contato'}</p>
                    </div>
                    {tic.modulos && (
                      <div className="pt-2 border-t border-slate-100">
                        <p className="text-[10px] text-slate-400 uppercase font-medium">Módulos Ativos / Observações</p>
                        <p className="text-xs text-slate-600 leading-relaxed font-medium mt-0.5">{tic.modulos}</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic py-2">Sem dados de TIC registrados.</p>
                )}
              </section>
            </div>

            {/* Coluna Direita: Especialidades & Dimensionamento de Leitos */}
            <div className="space-y-6">
              {/* Card: Especialidades */}
              <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <Activity className="w-4 h-4 text-slate-400" />
                    Especialidades Disponíveis
                  </h2>
                  {especialidadesInfo?.lista && especialidadesInfo.lista.length > 0 && (
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-[#122A54]/10 text-[#122A54] rounded">
                      {especialidadesInfo.lista.length} disponíveis
                    </span>
                  )}
                </div>

                {especialidadesInfo ? (
                  <div className="space-y-3">
                    {groupedEspecialidades && Object.keys(groupedEspecialidades).length > 0 ? (
                      <div className="space-y-3.5 max-h-[220px] overflow-y-auto custom-scrollbar pr-1.5">
                        {Object.entries(groupedEspecialidades).map(([tipo, items]) => (
                          <div key={tipo} className="space-y-1.5">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                              {tipo}
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {(items as string[]).map((spec, idx) => (
                                <span
                                  key={idx}
                                  className="px-2.5 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-md border border-slate-200/80 leading-normal transition-colors"
                                >
                                  {spec}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">Sem especialidades disponíveis no período</p>
                    )}

                    <p className="text-[10px] text-slate-400 font-medium pt-2 border-t border-slate-100">
                      Dados de referência: {especialidadesInfo.mes}/{especialidadesInfo.ano}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic py-2">Sem dado de especialidades registrado</p>
                )}
              </section>

              {/* Card: Dimensionamento de Leitos */}
              <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <Bed className="w-4 h-4 text-slate-400" />
                    Dimensionamento de Leitos
                  </h2>
                </div>

                {leitos ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="bg-slate-50 p-3 rounded-lg text-center border border-slate-100">
                      <p className="text-xl font-extrabold text-[#122A54]">{leitos.enfermaria || '0'}</p>
                      <p className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">Enferm.</p>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-lg text-center border border-slate-100">
                      <p className="text-xl font-extrabold text-[#122A54]">{leitos.cirurgia || '0'}</p>
                      <p className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">Cirurg.</p>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-lg text-center border border-slate-100">
                      <p className="text-xl font-extrabold text-blue-600">{leitos.uti || '0'}</p>
                      <p className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">UTI</p>
                    </div>
                    <div className="bg-[#122A54] p-3 rounded-lg text-center shadow-inner">
                      <p className="text-xl font-black text-white">{leitos.totalLeitos || '0'}</p>
                      <p className="text-[9px] text-blue-200 uppercase font-bold tracking-wider mt-0.5">Total</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic py-2">Sem dimensionamento registrado.</p>
                )}
              </section>
            </div>
          </div>
        )}

        {/* 2ª ABA: DESEMPENHO */}
        {activeTab === 'desempenho' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start" id="tab-content-desempenho">
            {/* Coluna Principal (lg:col-span-7): Produção vs Meta & Ajuste de Metas */}
            <div className="lg:col-span-7 space-y-6">
              {/* Card: Produção vs Meta */}
              <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4" id="production-vs-meta-section">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-slate-400" />
                    Produção vs Meta
                  </h2>
                  
                  {/* Period Selector */}
                  <div className="w-full sm:w-52">
                    <select
                      id="period-select-dropdown"
                      value={selectedPeriod}
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      disabled={periods.length === 0}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#122A54]/20 focus:border-[#122A54] transition cursor-pointer"
                    >
                      {periods.length === 0 ? (
                        <option value="">Nenhum período disponível</option>
                      ) : (
                        <>
                          <option value="">Selecione o período...</option>
                          {periods.map(p => (
                            <option key={p.key} value={p.key}>
                              {p.mes.toUpperCase()} / {p.ano}
                            </option>
                          ))}
                        </>
                      )}
                    </select>
                  </div>
                </div>

                {!selectedPeriod ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center px-4" id="select-period-prompt">
                    <Calendar className="w-8 h-8 text-slate-300 mb-2.5" />
                    <p className="text-xs font-semibold text-slate-500">Selecione um período para ver os dados de produção</p>
                  </div>
                ) : filteredProducao.length > 0 ? (
                  <div className="space-y-3.5 max-h-[380px] overflow-y-auto custom-scrollbar pr-1.5" id="production-indicators-list">
                    {filteredProducao.map((p, idx) => {
                      const metaNum = typeof p.meta === 'number' ? p.meta : parseFloat(String(p.meta || 0)) || 0;
                      const prodNum = typeof p.producao === 'number' ? p.producao : parseFloat(String(p.producao || 0)) || 0;
                      const ratio = metaNum > 0 ? Math.min(Math.round((prodNum / metaNum) * 100), 150) : 0;
                      const displayPercent = p.percentual ? String(p.percentual) : (metaNum > 0 ? `${Math.round((prodNum / metaNum) * 100)}%` : '0%');
                      
                      let barColor = 'bg-[#122A54]';
                      let textColor = 'text-[#122A54]';
                      
                      const statusMetaStr = String(p.statusMeta || '').toUpperCase();
                      const isCumprida = statusMetaStr.includes('CUMPRIDA') || ratio >= 100;
                      if (isCumprida) {
                        barColor = 'bg-emerald-500';
                        textColor = 'text-emerald-600';
                      } else if (ratio >= 85) {
                        barColor = 'bg-amber-500';
                        textColor = 'text-amber-600';
                      } else {
                        barColor = 'bg-red-500';
                        textColor = 'text-red-600';
                      }

                      return (
                        <div key={`${p.indicador}-${idx}`} className="space-y-1.5 p-3.5 bg-slate-50/70 rounded-lg border border-slate-100" id={`indicator-${idx}`}>
                          <div className="flex justify-between items-start gap-3">
                            <div className="space-y-0.5">
                              <h4 className="text-xs font-bold text-slate-800 leading-tight" title={p.indicador}>
                                {p.indicador}
                              </h4>
                              <p className="text-[9px] text-slate-400 font-bold uppercase font-mono">
                                Ref: {p.mes}/{p.ano}
                              </p>
                            </div>
                            <span className={`text-[9px] font-extrabold uppercase font-mono px-2 py-0.5 rounded shrink-0 ${
                              isCumprida ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : ratio >= 85 ? 'bg-amber-50 text-amber-800 border border-amber-100' : 'bg-red-50 text-red-800 border border-red-100'
                            }`}>
                              {p.statusMeta || (isCumprida ? 'CUMPRIDA' : 'ATENÇÃO')}
                            </span>
                          </div>

                          <div className="space-y-1.5 pt-1">
                            <div className="flex justify-between text-[11px] font-mono font-medium text-slate-500">
                              <span>Meta: <b className="text-slate-700 font-bold">{metaNum.toLocaleString('pt-BR')}</b></span>
                              <span>Prod: <b className="text-slate-700 font-bold">{prodNum.toLocaleString('pt-BR')}</b></span>
                              <span>Atingido: <b className={`${textColor} font-extrabold`}>{displayPercent}</b></span>
                            </div>
                            <div className="w-full bg-slate-200/80 h-2 rounded-full overflow-hidden">
                              <div 
                                className={`h-full ${barColor} rounded-full transition-all duration-300`}
                                style={{ width: `${Math.max(2, ratio)}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic py-12 text-center" id="no-production-data-prompt">Nenhum dado de produção lançado para este período.</p>
                )}
              </section>

              {/* Card: Ajuste de Metas de Produção */}
              {metasSugeridas.length > 0 && (
                <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-100">
                    <FileCheck className="w-4 h-4 text-slate-400" />
                    Ajuste de Metas de Produção
                  </h2>
                  <div className="relative">
                    <div className="space-y-3.5 max-h-[260px] overflow-y-auto pr-1.5 pb-2 custom-scrollbar">
                      {metasSugeridas.map((m, idx) => (
                        <div key={`${m.indicador}-${idx}`} className="p-3.5 bg-slate-50/70 rounded-lg border border-slate-100 text-xs space-y-2">
                          <h4 className="font-bold text-slate-800 leading-tight">{m.indicador}</h4>
                          <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono uppercase font-bold">
                            <div className="bg-white p-1.5 rounded border border-slate-100">
                              <span className="text-slate-400 block text-[8px]">Atual</span>
                              <span className="text-slate-700 block font-extrabold mt-0.5">{m.metaAtual}</span>
                            </div>
                            <div className="bg-white p-1.5 rounded border border-slate-100">
                              <span className="text-slate-400 block text-[8px]">Média</span>
                              <span className="text-slate-700 block font-extrabold mt-0.5">{m.producaoMediaRecente}</span>
                            </div>
                            <div className="bg-emerald-50 text-emerald-900 p-1.5 rounded border border-emerald-100">
                              <span className="text-emerald-800 block text-[8px]">Sugerida</span>
                              <span className="text-emerald-950 block font-black mt-0.5">{m.novaMetaSugerida}</span>
                            </div>
                          </div>
                          {m.justificativa && (
                            <p className="text-[10px] text-slate-500 leading-relaxed font-sans pt-1 border-t border-slate-200/40">
                              <span className="font-bold text-slate-400 uppercase text-[8px] block">Justificativa</span>
                              {m.justificativa}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              )}
            </div>

            {/* Coluna Secundária (lg:col-span-5): Análise de Desempenho CTAI */}
            <div className="lg:col-span-5 space-y-6">
              <section className="bg-[#122A54] text-white rounded-xl shadow-md p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
                  <h2 className="text-xs font-extrabold text-blue-200 uppercase tracking-wider flex items-center gap-2">
                    <Activity className="w-4 h-4 text-blue-300" />
                    Análise de Desempenho CTAI
                  </h2>
                </div>

                {analiseDesempenho ? (
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <p className="text-[10px] text-blue-300 uppercase font-bold tracking-wide">Pontos Fortes</p>
                      <p className="text-xs leading-relaxed text-blue-50 font-medium bg-white/5 p-2.5 rounded border border-white/10">
                        {analiseDesempenho.pontosFortes || 'Nenhum ponto registrado.'}
                      </p>
                    </div>
                    <div className="space-y-1.5">
                      <p className="text-[10px] text-amber-300 uppercase font-bold tracking-wide flex items-center justify-between">
                        <span>Debilidades</span>
                        {debilidadesCount > 0 && (
                          <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-200 text-[9px] rounded border border-amber-500/30 font-mono">
                            {debilidadesCount} {debilidadesCount === 1 ? 'registrada' : 'registradas'}
                          </span>
                        )}
                      </p>
                      <p className="text-xs leading-relaxed text-blue-50 font-medium bg-white/5 p-2.5 rounded border border-white/10">
                        {analiseDesempenho.debilidades || 'Nenhuma debilidade registrada.'}
                      </p>
                    </div>
                    {analiseDesempenho.sugestaoSuporteMonitoramento && (
                      <div className="space-y-1.5 pt-2 border-t border-blue-900/50">
                        <p className="text-[10px] text-blue-300 uppercase font-bold tracking-wide">Suporte & Monitoramento</p>
                        <p className="text-xs text-slate-200 leading-relaxed font-medium bg-white/5 p-2.5 rounded border border-white/10">
                          {analiseDesempenho.sugestaoSuporteMonitoramento}
                        </p>
                      </div>
                    )}
                    {analiseDesempenho.baseadoEm && (
                      <p className="text-[9px] text-blue-300/70 italic text-right mt-1">Ref: {analiseDesempenho.baseadoEm}</p>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-blue-200/60 italic py-4">Sem diagnóstico registrado.</p>
                )}
              </section>
            </div>
          </div>
        )}

        {/* 3ª ABA: FINANCEIRO */}
        {activeTab === 'financeiro' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start" id="tab-content-financeiro">
            {/* Repasses Financeiros */}
            <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4" id="section-repasses-financeiros">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-slate-400" />
                  Repasses Financeiros
                </h2>
                {repasses && repasses.length > 0 && (
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded">
                    {repasses.length} competência{repasses.length > 1 ? 's' : ''}
                  </span>
                )}
              </div>

              {(repasses && repasses.length > 0) ? (
                <div className="relative">
                  <div className="space-y-3.5 max-h-[480px] overflow-y-auto pr-1.5 pb-2 custom-scrollbar">
                    {repasses.map((r, idx) => {
                      const hasPendencia = r.pendencia && r.pendencia !== '-' && r.pendencia.trim() !== '';
                      const hasObservacoes = r.observacoes && r.observacoes !== '-' && r.observacoes.trim() !== '';

                      const saldoAPagarStr = (r.saldoAPagarOss && r.saldoAPagarOss !== '-') 
                        ? r.saldoAPagarOss 
                        : (r.saldoAPagarProvisaoFutura && r.saldoAPagarProvisaoFutura !== '-')
                          ? r.saldoAPagarProvisaoFutura
                          : '-';

                      return (
                        <div key={`${r.competencia}-${idx}`} className="p-3.5 border border-slate-200/80 rounded-lg bg-slate-50/50 space-y-2 text-xs">
                          <div className="flex justify-between items-center border-b border-slate-100 pb-2 mb-1.5">
                            <span className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider">
                              {r.competencia}
                            </span>
                            <span className="text-[9px] font-bold px-2 py-0.5 bg-slate-100 text-slate-600 rounded uppercase tracking-wide">
                              {r.tipo}
                            </span>
                          </div>

                          <div className="grid grid-cols-3 gap-1.5 text-center text-[10px] font-mono uppercase font-bold">
                            <div className="bg-white p-1.5 rounded border border-slate-100">
                              <span className="text-slate-400 block text-[8px]">Projeção</span>
                              <span className="text-slate-700 block font-extrabold mt-0.5">{r.projecao || '-'}</span>
                            </div>
                            <div className="bg-white p-1.5 rounded border border-slate-100">
                              <span className="text-slate-400 block text-[8px]">Descontos</span>
                              <span className="text-red-600 block font-extrabold mt-0.5">{r.descontos || '-'}</span>
                            </div>
                            <div className="bg-white p-1.5 rounded border border-slate-100">
                              <span className="text-slate-400 block text-[8px]">Pós-Desc.</span>
                              <span className="text-emerald-700 block font-extrabold mt-0.5">{r.projecaoAposDesconto || '-'}</span>
                            </div>
                          </div>

                          <div className="flex justify-between items-center text-xs px-1 py-1 font-mono bg-white rounded border border-slate-100">
                            <span className="text-slate-500 font-medium">Saldo a Pagar:</span>
                            <span className="font-extrabold text-[#122A54]">{saldoAPagarStr}</span>
                          </div>

                          {hasPendencia && (
                            <div className="flex items-start gap-2 p-2.5 bg-amber-50/90 border border-amber-200/80 rounded-lg text-xs text-amber-800 font-semibold leading-normal">
                              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                              <div>
                                <span className="font-bold uppercase text-[9px] block tracking-wide text-amber-700 mb-0.5">Pendência</span>
                                {r.pendencia}
                              </div>
                            </div>
                          )}

                          {hasObservacoes && (
                            <div className="text-[11px] text-slate-500 leading-relaxed font-sans pt-1.5 border-t border-slate-100">
                              <span className="font-bold text-slate-400 uppercase text-[8px] block tracking-wide">Observações</span>
                              {r.observacoes}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic py-8 text-center" id="no-repasses-data-prompt">Sem repasses registrados</p>
              )}
            </section>

            {/* Apontamentos de Desconto CTAI */}
            <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4" id="section-apontamentos-desconto">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-400" />
                  Apontamentos de Desconto CTAI
                </h2>
                {apontamentosDescontoList.length > 0 && (
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-amber-100 text-amber-800 rounded">
                    {apontamentosDescontoList.length} registrado{apontamentosDescontoList.length > 1 ? 's' : ''}
                  </span>
                )}
              </div>

              {apontamentosDescontoList.length > 0 ? (
                <div className="relative">
                  <div className="space-y-3.5 max-h-[480px] overflow-y-auto pr-1.5 pb-2 custom-scrollbar">
                    {apontamentosDescontoList.map((item, idx) => (
                      <div key={`${item.ano}-${item.trimestre}-${idx}`} className="p-3.5 border border-slate-200/80 rounded-lg bg-slate-50/50 space-y-2.5 text-xs">
                        <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                          <span className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider">
                            {item.trimestre} / {item.ano}
                          </span>
                          <span className="text-[9px] font-bold px-2 py-0.5 bg-amber-100 text-amber-800 rounded uppercase tracking-wide">
                            Desconto
                          </span>
                        </div>

                        {item.categoriaApontamento && (
                          <div className="text-xs text-slate-700 font-medium leading-relaxed">
                            <span className="text-[9px] font-bold text-slate-400 uppercase block tracking-wide mb-0.5">
                              Categoria do Apontamento
                            </span>
                            {item.categoriaApontamento}
                          </div>
                        )}

                        <div className="p-2.5 bg-amber-50/90 border border-amber-200/80 rounded-lg flex justify-between items-center text-xs">
                          <span className="font-bold text-amber-800 uppercase text-[9px] tracking-wide">
                            Percentual / Valor:
                          </span>
                          <span className="font-extrabold text-amber-900 font-mono text-xs">
                            {item.percentualValor || '-'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic py-8 text-center">
                  Nenhum desconto financeiro registrado
                </p>
              )}
            </section>
          </div>
        )}

        {/* 4ª ABA: PARECERES */}
        {activeTab === 'pareceres' && (
          <div className="space-y-6" id="tab-content-pareceres">
            <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4" id="section-pareceres-ctai">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h2 className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-4 h-4 text-slate-400" />
                    Histórico de Pareceres CTAI
                  </h2>
                  <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                    Acompanhamento técnico e avaliações de metas por trimestre
                  </p>
                </div>

                {/* Input de filtro/busca de pareceres */}
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Filtrar por ano, trimestre..."
                    value={parecerSearch}
                    onChange={(e) => setParecerSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#122A54]/20 focus:border-[#122A54] transition"
                  />
                </div>
              </div>

              {filteredPareceres.length > 0 ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredPareceres.map((p, idx) => {
                      const hasDesconto = String(p.temDescontoFinanceiro || '').toLowerCase().trim().startsWith('sim') || (p.pendenciasDescontos && String(p.pendenciasDescontos).trim() !== '' && String(p.pendenciasDescontos) !== '-');

                      return (
                        <div 
                          key={`${p.ano}-${p.trimestre}-${idx}`} 
                          className={`p-4 border rounded-xl space-y-3 text-xs transition-shadow hover:shadow-md ${
                            hasDesconto ? 'bg-amber-50/30 border-amber-200' : 'bg-slate-50/50 border-slate-200'
                          }`}
                        >
                          <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold text-[#122A54] uppercase tracking-wider font-mono">
                                {p.trimestre} / {p.ano}
                              </span>
                              {p.numeroParecer && (
                                <span className="px-2 py-0.5 bg-[#122A54]/10 text-[#122A54] text-[9px] font-extrabold rounded font-mono">
                                  Parecer Nº {p.numeroParecer}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono font-medium">{p.dataParecer || 'Sem data'}</span>
                          </div>

                          <div className="space-y-1.5">
                            <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Avaliação & Resumo das Metas</p>
                            <p className="text-xs font-medium leading-relaxed text-slate-800 bg-white p-2.5 rounded border border-slate-100">
                              {p.resumoMetas || 'Cumprimento de metas avaliado.'}
                            </p>
                          </div>

                          {p.pendenciasDescontos && (
                            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg space-y-0.5">
                              <p className="text-[9px] text-amber-700 font-bold uppercase tracking-wider">Pendências / Descontos</p>
                              <p className="text-xs font-semibold text-amber-900">{p.pendenciasDescontos}</p>
                            </div>
                          )}

                          {p.categoriaApontamento && (
                            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-bold">Categoria</p>
                                <p className="text-xs font-semibold text-slate-700">{p.categoriaApontamento}</p>
                              </div>
                              {p.percentualValor && (
                                <div>
                                  <p className="text-[9px] text-slate-400 uppercase font-bold">Percentual / Valor</p>
                                  <p className="text-xs font-extrabold text-amber-800 font-mono">{p.percentualValor}</p>
                                </div>
                              )}
                            </div>
                          )}

                          {p.observacoes && (
                            <div className="text-[10px] text-slate-500 leading-relaxed pt-1 border-t border-slate-100">
                              <span className="font-bold text-slate-400 uppercase text-[8px] block">Observações</span>
                              {p.observacoes}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic py-12 text-center">
                  {parecerSearch ? 'Nenhum parecer encontrado com os termos pesquisados.' : 'Sem pareceres cadastrados.'}
                </p>
              )}
            </section>
          </div>
        )}

        {/* FOOTER ACTIONS */}
        <div className="flex justify-start pt-4 border-t border-slate-200">
          <button
            onClick={onBack}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded uppercase tracking-wider transition-colors shadow-sm cursor-pointer"
            id="profile-back-bottom-btn"
          >
            Voltar para Unidades
          </button>
        </div>
      </div>
    </ErrorBoundary>
  );
}
