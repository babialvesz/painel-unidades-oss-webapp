import React from 'react';
import { OSSInfo } from '../types';
import { Building2, ChevronRight } from 'lucide-react';

interface OssGridProps {
  ossList: OSSInfo[];
  onSelectOss: (sigla: string) => void;
  isLoading: boolean;
}

export default function OssGrid({ ossList, onSelectOss, isLoading }: OssGridProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4" id="oss-grid-loading">
        <svg className="animate-spin h-8 w-8 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider font-sans">Carregando Organizações Sociais...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6" id="oss-grid-container">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="space-y-0.5">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <Building2 className="w-4.5 h-4.5 text-[#122A54]" />
            <span>Organizações Sociais de Saúde ({ossList.length})</span>
          </h2>
          <p className="text-[11px] text-slate-500">
            Selecione uma organização gerencial abaixo para detalhar suas respectivas unidades de saúde pactuadas.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="oss-cards-grid">
        {ossList.map((oss) => (
          <button
            key={oss.sigla}
            onClick={() => onSelectOss(oss.sigla)}
            className="w-full text-left bg-white border border-slate-200 rounded-xl p-5 hover:border-[#122A54] hover:shadow-lg transition-all duration-200 focus:outline-none flex flex-col justify-between group relative cursor-pointer"
            id={`oss-card-${oss.sigla}`}
          >
            <div className="space-y-4 w-full">
              <div className="flex items-center justify-between">
                <div className="px-2.5 py-0.5 bg-[#122A54]/5 group-hover:bg-[#122A54]/10 rounded text-[#122A54] text-[10px] font-bold font-mono uppercase tracking-wider transition-colors">
                  {oss.sigla}
                </div>
                <div className="text-[#122A54] opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-200">
                  <ChevronRight className="w-4.5 h-4.5 animate-pulse" />
                </div>
              </div>

              <div className="space-y-1">
                <h3 className="font-bold text-sm text-slate-900 group-hover:text-[#122A54] transition-colors leading-snug line-clamp-2">
                  {oss.razao_social || 'Sem Razão Social Registrada'}
                </h3>
                {oss.cnpj && (
                  <p className="text-[10px] text-slate-400 font-mono">CNPJ: {oss.cnpj}</p>
                )}
              </div>
            </div>

            <div className="border-t border-slate-100 mt-4 pt-3 flex items-center justify-between text-[11px] text-slate-500 w-full">
              <span className="font-semibold text-[#122A54] bg-[#122A54]/5 px-2 py-0.5 rounded uppercase text-[10px] tracking-wider">
                {oss.count} {oss.count === 1 ? 'unidade pactuada' : 'unidades pactuadas'}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
