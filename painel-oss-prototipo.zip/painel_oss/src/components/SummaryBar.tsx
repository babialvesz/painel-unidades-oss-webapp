import React from 'react';
import { Building2, Hospital, Activity, Stethoscope, Truck, BedDouble } from 'lucide-react';
import { HomeSummaryData } from '../types';

interface SummaryBarProps {
  summaryData: HomeSummaryData['summary'] | null;
  isLoading: boolean;
}

export default function SummaryBar({ summaryData, isLoading }: SummaryBarProps) {
  if (isLoading || !summaryData) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6" id="summary-bar-skeleton">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between shadow-xs animate-pulse">
            <div className="h-3 w-16 bg-slate-200 rounded mb-2"></div>
            <div className="h-7 w-12 bg-slate-200 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const items = [
    {
      label: 'OSS Gestoras',
      value: summaryData.totalOss,
      icon: Building2,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-blue-50 text-[#122A54]',
    },
    {
      label: 'Hospitais',
      value: summaryData.hospitaisCount,
      icon: Hospital,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-[#122A54]/10 text-[#122A54]',
    },
    {
      label: 'UPAs',
      value: summaryData.upasCount,
      icon: Activity,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-emerald-50 text-emerald-700',
    },
    {
      label: 'UPAEs',
      value: summaryData.upaesCount,
      icon: Stethoscope,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-amber-50 text-amber-700',
    },
    {
      label: 'Carretas',
      value: summaryData.carretasCount,
      icon: Truck,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-purple-50 text-purple-700',
    },
    {
      label: 'Leitos de UTI',
      value: summaryData.totalUti.toLocaleString('pt-BR'),
      icon: BedDouble,
      badgeColor: 'text-[#122A54]',
      iconBg: 'bg-rose-50 text-rose-700',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" id="summary-bar-container">
      {items.map((item, idx) => {
        const Icon = item.icon;
        return (
          <div
            key={idx}
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
            id={`summary-card-${idx}`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-tight truncate">
                {item.label}
              </span>
              <div className={`p-1.5 rounded-lg shrink-0 ${item.iconBg}`}>
                <Icon className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="flex items-baseline gap-1">
              <span className={`text-2xl font-black tracking-tight ${item.badgeColor}`}>
                {item.value}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
