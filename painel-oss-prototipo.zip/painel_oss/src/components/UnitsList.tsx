import React from 'react';
import { UnitSummary } from '../types';
import { MapPin, Tag, ArrowLeft, AlertCircle } from 'lucide-react';

interface UnitsListProps {
  units: UnitSummary[];
  title: string;
  subtitle?: string;
  onSelectUnit: (oss: string, name: string) => void;
  onBackToHome?: () => void;
  isLoading: boolean;
}

export default function UnitsList({ units, title, subtitle, onSelectUnit, onBackToHome, isLoading }: UnitsListProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4" id="units-list-loading">
        <svg className="animate-spin h-8 w-8 text-[#122A54]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider font-sans">Carregando unidades de saúde...</p>
      </div>
    );
  }

  // Sorter for Status priority: Amber, then Green, then Gray, then alphabetically by name
  const sortedUnits = [...units].sort((a, b) => {
    const statusPriority = { ambar: 1, verde: 2, cinza: 3 };
    const pA = statusPriority[a.status] || 99;
    const pB = statusPriority[b.status] || 99;
    if (pA !== pB) return pA - pB;
    return a.unidade.localeCompare(b.unidade);
  });

  return (
    <div className="space-y-6" id="units-list-container">
      {/* Header and Back navigation */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 pb-3">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="p-1.5 hover:bg-slate-100 rounded text-[#122A54] transition-colors mr-1 cursor-pointer"
                title="Voltar para Todas as OSS"
                id="units-back-btn"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans" id="units-list-title">
              {title}
            </h2>
          </div>
          {subtitle && <p className="text-[11px] text-slate-500 pl-1">{subtitle}</p>}
        </div>
        
        <div className="text-[10px] uppercase font-bold text-slate-400 font-mono md:text-right">
          Total de <span className="font-extrabold text-slate-700">{units.length}</span> {units.length === 1 ? 'unidade pactuada' : 'unidades pactuadas'}
        </div>
      </div>

      {units.length === 0 ? (
        <div className="p-8 text-center bg-white border border-slate-200 rounded-xl max-w-md mx-auto space-y-3 shadow-sm" id="units-empty">
          <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-900 uppercase">Nenhuma unidade encontrada</h3>
          <p className="text-xs text-slate-500">
            Não há registros compatíveis com os critérios selecionados nesta visualização.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="units-cards-grid">
          {sortedUnits.map((unit) => {
            // Status bullet color mapping
            const statusConfig = {
              verde: {
                color: 'bg-emerald-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]',
                label: 'Desempenho Estável (Pontos Fortes ativos)'
              },
              ambar: {
                color: 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]',
                label: 'Pontos de Atenção (Debilidades ativas)'
              },
              cinza: {
                color: 'bg-slate-400',
                label: 'Sem Análise de Desempenho registrada'
              }
            };
            const cfg = statusConfig[unit.status] || statusConfig.cinza;

            return (
              <button
                key={`${unit.oss}-${unit.unidade}`}
                onClick={() => onSelectUnit(unit.oss, unit.unidade)}
                className="w-full text-left bg-white border border-slate-200 rounded-xl p-5 hover:border-[#122A54] hover:shadow-lg transition-all duration-200 focus:outline-none flex flex-col justify-between group cursor-pointer"
                id={`unit-card-${unit.oss}-${unit.unidade.replace(/\s+/g, '-')}`}
              >
                <div className="space-y-4 w-full">
                  {/* Status Indicator Bar */}
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono bg-slate-100 px-2.5 py-0.5 rounded">
                      {unit.oss}
                    </span>
                    <div className="flex items-center space-x-1.5" title={cfg.label}>
                      <span className={`w-2.5 h-2.5 rounded-full ${cfg.color} shrink-0`}></span>
                      <span className="text-[10px] text-slate-400 font-bold uppercase font-mono tracking-wider">
                        {unit.status === 'verde' ? 'Estável' : unit.status === 'ambar' ? 'Atenção' : 'Sem Info'}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold text-sm text-slate-900 group-hover:text-[#122A54] transition-colors leading-snug line-clamp-2" id="unit-card-title">
                      {unit.unidade}
                    </h3>
                  </div>
                </div>

                {/* Meta details */}
                <div className="border-t border-slate-100 mt-4 pt-3 flex flex-wrap gap-y-2 gap-x-4 text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono w-full justify-between">
                  <div className="flex items-center space-x-1.5 shrink truncate">
                    <Tag className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{unit.tipo || 'Sem Tipo'}</span>
                  </div>
                  <div className="flex items-center space-x-1.5 shrink truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate text-slate-500">{unit.cidade || 'Sem Cidade'}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
