import express from 'express';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;
app.use(express.json());

// ============================================================
// Este é um PROTÓTIPO/ESQUELETO que demonstra a arquitetura
// da aplicação real, com dados e regras de negócio fictícios.
// Fonte de dados, credenciais e nomes de OSS foram substituídos.
// ============================================================

const SPREADSHEET_ID = "SEU_SPREADSHEET_ID_AQUI";

interface CacheData {
  unidades: any[];
  ossList: any[];
  tic: any[];
  leitos: any[];
  lastUpdated: number;
}

let dataCache: CacheData | null = null;
let isFetching = false;

// --- Parser de CSV robusto (lida com aspas e quebras de linha em células) ---
function parseCSV(text: string): Record<string, string>[] {
  const lines: string[][] = [];
  let row: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (char === '"') {
        if (next === '"') { current += '"'; i++; }
        else { inQuotes = false; }
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        row.push(current); current = '';
      } else if (char === '\r' || char === '\n') {
        row.push(current); current = '';
        if (row.length > 0 && row.some(cell => cell.trim() !== '')) lines.push(row);
        row = [];
        if (char === '\r' && next === '\n') i++;
      } else {
        current += char;
      }
    }
  }
  if (row.length > 0 || current !== '') {
    row.push(current);
    if (row.some(cell => cell.trim() !== '')) lines.push(row);
  }

  if (lines.length < 2) return [];
  const headers = lines[0].map(h => h.replace(/^"(.*)"$/, '$1').trim());
  const data: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const rowData = lines[i];
    const item: Record<string, string> = {};
    for (let j = 0; j < headers.length; j++) {
      let val = (rowData[j] || '').trim();
      if (val.startsWith('"') && val.endsWith('"')) val = val.substring(1, val.length - 1).trim();
      item[headers[j]] = val;
    }
    data.push(item);
  }
  return data;
}

// --- Normalização de texto para comparação (remove acentos, pontuação, etc.) ---
function normalizeText(text: string): string {
  if (!text) return '';
  return text.toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// --- Mapa de palavras-chave por OSS, usado para casar grafias inconsistentes ---
// Exemplo fictício: nomes reais de organizações e suas variações de escrita
// foram substituídos por entidades de demonstração.
const SIGLA_KEYWORDS: Record<string, string[]> = {
  OSS_A: ["oss a", "fundacao alfa", "gestao hospitalar alfa"],
  OSS_B: ["oss b", "instituto beta", "medicina integral beta"],
  OSS_C: ["oss c", "sociedade gama", "combate a doenca gama"],
  OSS_D: ["oss d", "protecao a maternidade delta"],
};

function isOssMatch(rowOss: string, targetSigla: string): boolean {
  if (!rowOss) return false;
  const rOssNorm = normalizeText(rowOss);
  const tSigla = targetSigla.trim().toUpperCase();

  const keywords = SIGLA_KEYWORDS[tSigla] || [];
  for (const keyword of keywords) {
    if (rOssNorm.includes(normalizeText(keyword))) return true;
  }
  return false;
}

// --- Comparação aproximada de nomes de unidade (tolera pequenas variações) ---
function isApproximateMatch(nameA: string, nameB: string): boolean {
  const a = normalizeText(nameA);
  const b = normalizeText(nameB);
  if (!a || !b) return false;
  if (a === b) return true;

  const wordsA = a.split(" ");
  const wordsB = b.split(" ");
  const intersection = wordsA.filter(w => wordsB.includes(w));
  const minLength = Math.min(wordsA.length, wordsB.length);
  return (intersection.length / minLength) >= 0.7;
}

// --- Engine de cache e busca de dados (simulado — em produção, busca via export CSV do Sheets) ---
async function fetchAllData(): Promise<CacheData> {
  // Em produção: fetch das abas via
  // https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet={aba}
  // seguido de parseCSV(texto) para cada fonte (unidades, OSS, TIC, leitos, etc.)
  //
  // Nesta versão de demonstração, retorna dados fictícios estáticos.
  return {
    unidades: [
      { OSS: "OSS_A", UNIDADE: "Unidade Demo 1" },
      { OSS: "OSS_B", UNIDADE: "Unidade Demo 2" },
    ],
    ossList: ["OSS_A", "OSS_B", "OSS_C", "OSS_D"],
    tic: [{ OSS: "OSS_A", Unidade: "Unidade Demo 1", status: "OK" }],
    leitos: [{ OSS: "OSS_A", Unidade: "Unidade Demo 1", total: 42 }],
    lastUpdated: Date.now(),
  };
}

async function getCachedData(): Promise<CacheData> {
  const CACHE_TTL_MS = 5 * 60 * 1000;
  if (dataCache && (Date.now() - dataCache.lastUpdated) < CACHE_TTL_MS) {
    return dataCache;
  }
  if (isFetching && dataCache) return dataCache; // serve stale enquanto atualiza
  isFetching = true;
  try {
    dataCache = await fetchAllData();
    return dataCache;
  } finally {
    isFetching = false;
  }
}

// ============================================================
// AUTENTICAÇÃO (Firebase Auth via Google OAuth)
// ============================================================

async function verifyFirebaseToken(token: string): Promise<{ email: string } | null> {
  // Em produção: valida o token via endpoint accounts:lookup do Identity Toolkit,
  // usando a API key do projeto Firebase (variável de ambiente).
  // Nesta versão de demonstração, a validação real foi omitida.
  return null;
}

async function authMiddleware(req: express.Request, res: express.Response, next: express.NextFunction) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Token ausente" });

  const user = await verifyFirebaseToken(token);
  if (!user) return res.status(401).json({ error: "Token inválido" });

  const email = user.email.toLowerCase();

  // Lista de e-mails autorizados individualmente (exemplo — configure a sua)
  const allowedIndividualEmails = [
    "seu.email@gmail.com",
  ];

  let isAuthorized = false;
  if (allowedIndividualEmails.includes(email)) {
    isAuthorized = true;
  } else if (email.endsWith("@ses.pe.gov.br")) {
    isAuthorized = true;
  } else if (process.env.AUTHORIZED_EMAILS) {
    const authEmails = process.env.AUTHORIZED_EMAILS.split(",").map(e => e.trim().toLowerCase());
    if (authEmails.includes(email)) isAuthorized = true;
  }

  if (!isAuthorized) return res.status(403).json({ error: "E-mail não autorizado" });

  next();
}

// ============================================================
// ENDPOINTS DA API
// ============================================================

app.get("/api/oss", authMiddleware, async (req, res) => {
  const data = await getCachedData();
  res.json(data.ossList);
});

app.get("/api/units", authMiddleware, async (req, res) => {
  const data = await getCachedData();
  res.json(data.unidades);
});

// Endpoint representativo: junta dados de múltiplas fontes (TIC + Leitos)
// para uma unidade específica. Em produção, o mesmo padrão se repete para
// pareceres técnicos, produção, contratos e especialidades.
app.get("/api/units/detail", authMiddleware, async (req, res) => {
  try {
    const { oss, unidade } = req.query as { oss: string; unidade: string };
    if (!oss || !unidade) {
      return res.status(400).json({ error: "Parâmetros oss e unidade são obrigatórios" });
    }

    const data = await getCachedData();

    const rawUnit = data.unidades.find(u =>
      (u.OSS || '').toUpperCase() === oss.toUpperCase() &&
      isApproximateMatch(u.UNIDADE || '', unidade)
    );

    if (!rawUnit) {
      return res.status(404).json({ error: "Unidade não localizada" });
    }

    const matchedTic = data.tic.find(t =>
      isOssMatch(t.OSS || '', oss) && isApproximateMatch(t.Unidade || '', unidade)
    );

    const matchedLeitos = data.leitos.find(l =>
      isOssMatch(l.OSS || '', oss) && isApproximateMatch(l.Unidade || '', unidade)
    );

    res.json({
      identificacao: rawUnit,
      tic: matchedTic || null,
      leitos: matchedLeitos || null,
      // outras fontes (pareceres, produção, contratos, especialidades)
      // seguem exatamente o mesmo padrão de busca + matching acima
    });
  } catch (err) {
    res.status(500).json({ error: "Erro ao montar detalhe da unidade" });
  }
});

// ============================================================
// START
// ============================================================

app.listen(PORT, () => {
  console.log(`Servidor de demonstração rodando em http://localhost:${PORT}`);
});
